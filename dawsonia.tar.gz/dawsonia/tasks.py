"""Input for ``invoke`` task runner.

Installation
------------
Using pip::
    pip3 install --user -U invoke importlib-metadata

or with `pipx <https://pypa.github.io/pipx/>`__::
    pipx install invoke
    pipx inject invoke importlib-metadata

Usage
-----
Use the command ``invoke`` or ``inv``

List all tasks::
    invoke --list

Run a task, for example ``install``::
    invoke install

"""

import importlib.metadata as importlib_metadata
import os
import platform
import sys
from concurrent.futures import ProcessPoolExecutor as Pool
from concurrent.futures import wait
from datetime import datetime
from getpass import getuser
from pathlib import Path
from shutil import rmtree, which

import pkg_resources
from invoke import Collection, call, task
from pkg_resources.extern.packaging.markers import UndefinedEnvironmentName

# from packaging.markers import UndefinedEnvironmentName


if os.getenv("SMHI_MODE"):
    if platform.system() == "Linux":
        SYSTEM_PYTHON = "/usr/bin/python3.9"
    else:
        SYSTEM_PYTHON = "python3.9"
else:
    SYSTEM_PYTHON = sys.executable

HERE = Path(__file__).parent
os.chdir(HERE)



@task
def set_prefix(c):
    """Set environment variables to use a custom prefix to install applications.
    Only executes if the ``CI`` enviroment variable is set.

    Notes
    -----
    Equivalent to performing ``export`` in bash. Docs on the usage of the
    environment variables set in this task.

    * https://specifications.freedesktop.org/basedir-spec/basedir-spec-latest.html
    * https://pip.pypa.io/en/stable/topics/configuration/
    * https://pre-commit.com/index.html#managing-ci-caches
    * https://pypa.github.io/pipx/installation/#installation-options

    """
    if not os.getenv("CI"):
        return

    prefix = "/local_disk/gitlab-python-var"
    os.makedirs(prefix, exist_ok=True)

    OLD_PATH_ENV = os.getenv("PATH", "")

    custom_env_vars = dict(
        PYTHONUSERBASE=prefix,
        PATH=f"{prefix}/bin:{OLD_PATH_ENV}",
        XDG_CACHE_HOME=f"{prefix}/cache",
        XDG_DATA_HOME=f"{prefix}/data",
        # Not necessary since pip and pre-commit respects XDG_CACHE_HOME
        # PIP_CACHE_DIR=f"{prefix}/cache/pip",
        # PRE_COMMIT_HOME=f"{prefix}/cache/pre-commit",
        PIPX_HOME=f"{prefix}/data/pipx",
        PIPX_BIN_DIR=f"{prefix}/bin",
    )

    print(f"Setting environment variables {custom_env_vars.keys()} under {prefix}")

    os.environ.update(custom_env_vars)


def rm_if_exists(path):
    if os.path.exists(path):
        rmtree(path)


def current_python(c):
    if which("pyenv"):
        return c.run("pyenv which python3").stdout
    else:
        return which("python3")


def pkg_mandatory(reqt):
    if not reqt.marker:
        return True

    try:
        return reqt.marker.evaluate()
    except UndefinedEnvironmentName:
        # possibly an "extra" marker
        return False


def parse_requirements(requires):
    packages = [
        reqt.name
        for reqt in pkg_resources.parse_requirements("\n".join(requires))
        if pkg_mandatory(reqt)
    ]
    return packages


def extract_metadata():
    """Extract packaging metadata of the current package from src/<pkg>.egg-info
    directory.

    """
    dist = next(importlib_metadata.Distribution.discover(path=["src"]))

    requires = " ".join(f"python3-{pkg}" for pkg in parse_requirements(dist.requires))
    print("Requirements:", requires)
    return dist, requires


def make_release_number():
    return datetime.now().strftime("%H%M")


@task
def clean(c, dist=False):
    """Clean build (and optionally dist) directory"""
    rm_if_exists(HERE / "build")

    for egg_info in HERE.glob("**/*.egg-info"):
        rmtree(egg_info)

    for egg_info in HERE.glob("**/__pycache__"):
        rmtree(egg_info)

    if dist:
        rm_if_exists(HERE / "dist")


@task
def build_egg(c):
    """Generate metadata under src/*.egg-info/"""
    c.run("python3 setup.py egg_info")


@task(clean)
def build_pip(c, wheel=False):
    """Build pip / PyPI compatible packages into dist/ directory"""
    c.run("python3 setup.py sdist")
    if wheel:
        c.run("python3 setup.py bdist_wheel")


@task(clean, build_egg)
def build_rpm(c, spec_only=False):
    """Build rpm packages / spec files using ``bdist_rpm`` setuptools command.

    https://setuptools.pypa.io/en/stable/deprecated/distutils/builtdist.html#creating-rpm-packages
    """
    _, requires = extract_metadata()
    release = make_release_number()

    rpm_options = f"--packager {getuser()}  --release {release} "
    if requires:
        rpm_options += f"--requires '{requires}' "

    python_exe = current_python(c)

    if spec_only:
        c.run(f"python3 setup.py bdist_rpm --spec-only {rpm_options}")
    else:
        if not python_exe.startswith("/usr/bin/python3"):
            raise RuntimeError(
                "Execute the task only with the system Python. "
                f"Currently using {python_exe}"
            )
        c.run(f"python3 setup.py bdist_rpm --binary-only {rpm_options}")


@task(set_prefix)
def install(c, editable=False, extras_require="", force=""):
    """Install the package in the home directory or current virtual environment
    using ``pip3 install``.

    Parameters
    ----------
    editable: bool
        Useful for development.
    extras_require: str
        Extra requirements as specified in ``setup.cfg``.
    force: str
        Force installation of the package, excluding dependencies, even if
        already available from a previous installation. Two possible options are
        allowed: "reinstall" or "ignore" which triggers
        - ``pip install --force-reinstall --no-deps ...`` or
        - ``pip install --ignore-installed --no-deps ...``
        respectively.

    """
    requirement = f"'.[{extras_require}]'" if extras_require else "."

    pip_options = " "
    if current_python(c).startswith("/usr/bin/python3"):
        pip_options += "--user "

    if force == "reinstall":
        pip_options += "--force-reinstall --no-deps "
    elif force == "ignore":
        pip_options += "--ignore-installed --no-deps "
    elif force:
        raise ValueError("Unknown value supplied for --force")

    if editable:
        requirement = f"--editable {requirement} -r requirements/dev.txt"
    else:
        requirement = f"{requirement} -r requirements/main.txt "

    c.run(f"pip3 install {pip_options} {requirement}")


@task(set_prefix)
def install_pipx(c):
    """Install pipx, a tool to install other tools in separated virtual environments"""
    if which("pipx"):
        print("pipx is available")
        return

    c.run(f"{SYSTEM_PYTHON} -m pip install --user pipx")


def _install_tool_with_pipx(c, tool):
    if which(tool):
        print(f"{tool} is available")
        return

    c.run(f"pipx install --python {SYSTEM_PYTHON} {tool}")


@task(install_pipx)
def install_pre_commit(c):
    """Install pre-commit, a tool to configure git hooks"""
    _install_tool_with_pipx(c, "pre-commit")


@task(install_pre_commit)
def install_git_hooks(c):
    """Install pre-commit git hooks"""
    c.run("pre-commit install")


@task(install_git_hooks)
def run_pre_commit(c, from_branch="main"):
    """Execute pre-commit on changes ``from_branch`` to current revision"""
    c.run(f"git fetch origin {from_branch}")
    c.run(f"pre-commit run --from-ref origin/{from_branch} --to-ref HEAD")


@task(pre=[call(install, editable=True, extras_require="dev"), install_git_hooks])
def dev_install(_):
    """Install in editable mode for development"""


@task(pre=[call(install, editable=True, extras_require="docs"), install_git_hooks])
def docs_install(_):
    """Install in editable mode for building docs"""


@task
def docs_build(c):
    """Build the docs using sphinx-autobuild"""
    c.run("make -C docs autobuild")


@task
def docs_clean(c):
    """Clean the docs"""
    c.run("make -C docs clean")


@task(install_pipx)
def install_nox(c):
    """Install nox test runner"""
    _install_tool_with_pipx(c, "nox")


@task(set_prefix, iterable=["session"])
def nox(c, ensure_install=False, cov=False, session=None, options=""):
    """Execute ``nox``

    Parameters
    ----------
    ensure_install: bool
        Ensure package and test dependencies are installed.
    cov: bool
        Activate coverage report
    session: iterable
        List of sessions to run. Repeat the option to include more sessions.
        Example ``invoke nox -s tests -s types``.
    options: str
        Extra options to pass to ``nox``

    """
    if ensure_install:
        install_nox(c)

    nox = f"nox {options}" if options else "nox"

    if cov:
        c.run(f"{nox} -s tests_cov types_cov", pty=True)
    elif session:
        c.run(f"{nox} -s " + " ".join(session), pty=True)
    else:
        c.run(f"{nox}", pty=True)


@task
def pip_compile(c, upgrade=False):
    """Execute ``pip-compile`` to pin dependencies"""
    options = "--resolver backtracking --quiet --no-emit-index-url"
    if upgrade:
        options += " --upgrade"

    src = "setup.cfg"
    futures = []
    with Pool(max_workers=4) as pool:
        futures.append(
            pool.submit(
                c.run,
                f"pip-compile {options} -o requirements/main.txt --extra pypi {src}",
                pty=True,
            )
        )
        for extra in "docs", "dev":
            futures.append(
                pool.submit(
                    c.run,
                    f"pip-compile {options} -o requirements/{extra}.txt --extra"
                    f" {extra} {src}",
                    pty=True,
                )
            )

    wait(futures)


@task
def pip_sync(c, dev=False):
    """Execute ``pip-sync`` to synchronize dependencies"""
    req = "dev" if dev else "main"
    c.run(f"pip-sync requirements/{req}.txt requirements/self.txt")


@task
def mamba_export(c):
    """Export mamba environment to a ``environment_full.yaml`` file"""
    env_yaml = "./requirements/environment_full.yaml"
    c.run(f"mamba env export -f {env_yaml}")
    c.run(rf"sed -i 's/^prefix:.*//' {env_yaml}")


@task
def jupyter(c, partition="small-g"):
    os.chdir(HERE)
    job_id = c.run(
        f"sbatch --parsable --{partition=} {HERE}/scripts/launch-jupyter-slurm.sh"
    )
    c.run(f"watch tail -n 21 slurm-{job_id.stdout.strip()}.out")



@task
def tensorboard(c, partition="small-g"):
    c.run(f"sbatch --{partition=} {HERE}/scripts/launch-tensorboard-slurm.sh")


@task
def containerize(c, new=False):
    requirements = HERE / "requirements" / "lumi.txt"
    build_dir = HERE / "build"
    if new:
        build_dir.mkdir()
        do = f"new --prefix {build_dir} {requirements}"
    else:
        do = f"update -r {requirements} {build_dir}"
    c.run(f"pip-containerize {do}")


ns = Collection()
ns.add_task(install)

dev = Collection("dev")
dev.add_task(dev_install, "install")
dev.add_task(install_nox)
ns.add_collection(dev)

docs = Collection("docs")
docs.add_task(docs_install, "install")
docs.add_task(docs_build, "build")
docs.add_task(docs_clean, "clean")
ns.add_collection(docs)

maint = Collection("maint")
maint.add_task(build_pip)
maint.add_task(build_rpm)
maint.add_task(clean)
maint.add_task(pip_compile)
maint.add_task(pip_sync)
maint.add_task(mamba_export)
ns.add_collection(maint)

test = Collection("test")
test.add_task(nox)
test.add_task(run_pre_commit)
ns.add_collection(test)

hpc = Collection("hpc")
hpc.add_task(jupyter)
hpc.add_task(tensorboard)
hpc.add_task(containerize)
ns.add_collection(hpc)
