"""Input for ``nox`` test runner.

Installation
------------
Using pip::
    pip3 install --user -U nox

or with `pipx <https://pypa.github.io/pipx/>`__::
    pipx install nox

Usage
-----
Run::
    nox
    nox --list
    nox -s [SESSIONS [SESSIONS ...]]

Examples::
    # Run 'tests' session, in existing virtualenv
    nox -rs tests
    # Run 'tests' session, in existing virtualenv, skip installation and
    # provide extra CLI arguments
    nox -Rs tests -- --last-failed --pdb
    # Run 'types' session in strict mode
    nox -Rs types -- --strict

"""

import os
from pathlib import Path

import nox

# Default session
nox.options.sessions = ["tests", "types"]

PATHS_INPUT_MYPY = ["src", "scripts", "tests"]
PATH_OUTPUT_COV = Path(".coverage_reports")
if os.getenv("CI"):
    pytest_temp_dir = Path.cwd() / ".pytest_cache" / "tmp"
    pytest_temp_dir.mkdir(exist_ok=True, parents=True)
    PYTEST_OPTS: "tuple[str, ...]" = ("--runslow", f"--basetemp={pytest_temp_dir}")
else:
    PYTEST_OPTS = ()


# NOTE: known issue in specifying Python interpreter
# https://github.com/wntrblm/nox/issues/384
# https://github.com/wntrblm/nox/issues/623


@nox.session(python=["3.9"])
def tests(session):
    """Installs in isolation and executes pytest+pytest-xdist"""
    session.install("-r", "requirements/main.txt", ".[pypi,tests]")

    no_posargs = "-n", "auto", "--maxprocesses=4"
    options = _make_session_opts(
        PYTEST_OPTS,
        session.posargs,
        no_posargs,
    )

    session.run("pytest", "-s", "--verbose", *options)


@nox.session(python=["3.9"], venv_params=["--system-site-packages"])
def tests_cov(session):
    """Installs in editable mode with system site packages and executes
    pytest+pytest-cov

    """
    session.install("-r", "requirements/main.txt", "--editable", ".[pypi,tests]")

    options = _make_session_opts(PYTEST_OPTS, session.posargs)

    session.run(
        "python",
        "-m",
        "pytest",
        "-s",
        "--verbose",
        "--cov=src",
        "--cov=tests",
        f"--cov-report=xml:{PATH_OUTPUT_COV}/pytest.xml",
        "--cov-report=term-missing",
        "--no-cov-on-fail",
        *options,
    )


@nox.session(python=["3.9"])
def docs(session):
    """Installs in editable mode and builds docs using Sphinx and Make. For
    autobuild / live preview:

    nox -Rs docs -- autobuild

    """
    session.install("-r", "requirements/docs.txt", "-r", "requirements/self.txt")
    session.chdir("./docs")
    if session.posargs:
        options = session.posargs
    else:
        options = ("html",)
    session.run("make", *options, external=True)


@nox.session(python=["3.9"])
def types(session):
    """Installs in editable mode and executes type checking using mypy"""
    session.install("-r", "requirements/main.txt", "--editable", ".[pypi,types]")
    no_posargs = ("--sqlite-cache",)
    options = _make_session_opts(PATHS_INPUT_MYPY, session.posargs, no_posargs)
    session.run("mypy", *options)


@nox.session(python=["3.9"])
def types_daemon(session):
    """Installs in editable mode and executes type checking using dmypy"""
    session.install("-r", "requirements/main.txt", "--editable", ".[pypi,types]")
    no_posargs = "--sqlite-cache", "--use-fine-grained-cache"
    options = _make_session_opts(PATHS_INPUT_MYPY, session.posargs, no_posargs)
    session.run("dmypy", "run", "--", *options, success_codes=[0, 1])
    print("Daemon running in background. Use:\n  dmypy check src\n  dmypy stop")


@nox.session(python=["3.9"], venv_params=["--system-site-packages"])
def types_cov(session):
    """Installs in editable mode with system site packages and executes type checking
    using mypy and generates coverage reports

    """
    session.install("-r", "requirements/main.txt", "--editable", ".[pypi,types]")
    no_posargs = ("--sqlite-cache",)
    options = _make_session_opts(PATHS_INPUT_MYPY, session.posargs, no_posargs)
    session.run(
        "python",
        "-m",
        "mypy",
        f"--txt-report={PATH_OUTPUT_COV}",
        f"--cobertura-xml-report={PATH_OUTPUT_COV}",
        *options,
    )
    mypy_txt = PATH_OUTPUT_COV / "index.txt"
    mypy_xml = PATH_OUTPUT_COV / "cobertura.xml"
    if mypy_txt.exists():
        print(mypy_txt.read_text())

    if mypy_xml:
        print("Coverage XML written to file", mypy_xml)


@nox.session(python=["3.9"])
def ci(session):
    """Sessions to run on CI"""
    # Here we queue up the sessions to run
    session.notify("tests")
    session.notify("tests_cov")
    session.notify("types_cov")


def _make_session_opts(common_args, posargs, no_posargs=()):
    if posargs:
        options = *posargs, *common_args
    else:
        # Default options when no positional arguments are passed
        options = *no_posargs, *common_args
    return options
