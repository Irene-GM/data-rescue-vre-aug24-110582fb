# Contributing guide #

This is a shared contributing guide applying to all the projects of
AiForObs, including the current project, Dawsonia.

*Note this contributing guide itself is a work in progress and is meant to be
collaboratively improved. Please contribute!*

## Interested in contributing to Dawsonia?

Contributions welcome, but first:

::::{card} {fas}`envelope` Contact us
:link: mailto:smhi@smhi.se?subject=[Dawsonia:Samhällsberedskap-Modell_och_system-Metod]

Email us to [smhi@smhi.se](mailto:smhi@smhi.se)
and mention your request to be directed to *"Samhällsberedskap - Modell och system - Metod"* group.

::::

## Get access!

If you wish to submit changes in the code, you should have

1. an account at git.smhi.se (contact to get one)
2. a [personal access token](https://git.smhi.se/-/user_settings/personal_access_tokens) with all scopes (api, read, write etc.)


**The easiest way to proceed** is to modify the remote URL to clone from:

```sh
git clone https://<my-user-id>:<my-token>@git.smhi.se/ai-for-obs/dawsonia.git
```

**Alternatively**, you can add the following `~/.gitconfig`:

```cfg
[credential "https://git.smhi.se"]
        helper = libsecret
```

and run this to save the token in your current session:

```sh
echo -n <YOUR_PERSONAL_ACCESS_TOKEN> | /usr/bin/gnome-keyring-daemon --replace --unlock
```
