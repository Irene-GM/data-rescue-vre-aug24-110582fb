# AiForObs: DAWSONIA

Digitize hAndWritten obServatiONs In weather journAls

## Installation for development

### On Linux

```sh
python3 -m venv venv
source venv/bin/activate
python -m pip install invoke nox pip-tools

# Shell aliases and variables
echo "alias workon-dawsonia='source $PWD/venv/bin/activate'" >> ~/.bashrc
source ~/.bashrc

git clone https://git.smhi.se/ai-for-obs/dawsonia.git
cd dawsonia
invoke dev.install
```

## Quick start

Activate virtual environment using `workon-dawsonia` alias.

### Labelling pdf to create images

```sh
dawsonia label -c cfg/dawsonia.toml --interactive
```
Check `dawsonia label --help` for all possible options. It relies on two
configurations files `cfg/dawsonia.toml` and a station file in `table_formats`
directory.

### Prepare training, validation and test datasets and transform it into a HDF5 file

```sh
dawsonia prepare -c cfg/dawsonia.toml
dawsonia ml --transform -c cfg/dawsonia.toml
```

All files are created by default in `/local_disk/data/ai-for-obs/interim` which
contains a Makefile.  To archive previous training into a tarball `make tar` and
to continue from previous training `make untar`.

### Train the ML model

```sh
dawsonia ml --train -c cfg/dawsonia.toml
```

## Debugging

Activate debug mode by setting the environment variable
`export DAWSONIA_DEBUG=1`. You can also prepend it as follows:


```sh
DAWSONIA_DEBUG=1 dawsonia label -c cfg/dawsonia.toml --first-page 3 --last-page 4
```

Also useful is another environment variable `DAWSONIA_DEBUG_TABLE_DETECT` for the same command
