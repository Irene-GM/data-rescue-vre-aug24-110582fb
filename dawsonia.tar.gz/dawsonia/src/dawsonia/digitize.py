"""Pipeline to digitize PDFs

Setting environment variable DEBUG=1 shows values which get discarded.

"""

# NOTE: we disable this here because default options can be represented using typing.Annotated
# from __future__ import annotations

import json
import logging
import os
from collections.abc import Callable
from concurrent.futures import Executor, Future
from dataclasses import asdict, dataclass, field
from functools import lru_cache, partial
from pathlib import Path
from typing import Annotated, ClassVar, Type

import imageio.v3 as iio
import numpy as np
import pandas as pd
import typer
from numpy.typing import NDArray

import dawsonia
from dawsonia.config import config_cli_names, config_kwargs

# from dawsonia.image_preproc import preprocessed_image_pos_size
from dawsonia.exceptions import PredictionError
from dawsonia.io import Book, read_book
from dawsonia.typing import (
    MarkArray,
    Prediction,
    Probability,
    TablePosArrays,
    TableSizes,
)

logger = logging.getLogger(__name__)
DAWSONIA_DEBUG_DIGITIZE = bool(os.getenv("DAWSONIA_DEBUG", 0)) or bool(
    os.getenv("DAWSONIA_DEBUG_DIGITIZE", 0)
)


@dataclass
class _Metadata:
    _subdir: ClassVar[str] = ""
    _ext: ClassVar[str] = ".json"

    @classmethod
    def _metadata_relative_to_output_path(cls, output_path: Path) -> Path:
        return output_path.parent / cls._subdir / output_path.with_suffix(cls._ext).name

    @classmethod
    def ensure_output_path(cls, path) -> Path:
        if path.suffix != ".json":
            meta_file = cls._metadata_relative_to_output_path(path)
        else:
            meta_file = path

        meta_file.parent.mkdir(exist_ok=True)
        return meta_file

    def to_json(self, path: Path):
        """Writes JSON file to the path pointing to the file or relative to the
        output path of the main result.

        """
        meta_json = self.ensure_output_path(path)
        meta_json.write_text(json.dumps(asdict(self)))

    @classmethod
    def from_json(cls, path: "Path | str"):
        with open(path, encoding="utf-8") as fp:
            meta = json.load(fp)
        return cls(**meta)


@dataclass
class Statistics(_Metadata):
    tables_detected: int = 0
    predictions_total: int = 0
    predictions_above_thresh: int = 0
    predictions_empty_value: int = 0
    unset_values: int = 0
    _subdir: ClassVar[str] = "statistics"

    def compute(
        self, result: pd.DataFrame, probablities: pd.DataFrame, prob_thresh: float
    ):
        self.predictions_total = int(result.count().sum())
        self.predictions_above_thresh = int((probablities > prob_thresh).sum().sum())
        self.predictions_empty_value = int(
            result.applymap(lambda x: int(x == "")).sum().sum()
        )
        self.unset_values = int(result.applymap(lambda x: int(x is None)).sum().sum())


@dataclass
class Page(_Metadata):
    image: NDArray = field(repr=False)
    _subdir: ClassVar[str] = "pages"
    _ext: ClassVar[str] = ".webp"

    def to_image(self, path):
        image_path = self.ensure_output_path(path)
        iio.imwrite(image_path, self.image, plugin="pillow", lossless=True)


@dataclass
class TableMetadata(_Metadata):
    table_sizes: list[list[int]] = field(default_factory=list)
    table_positions: list[list[float]] = field(default_factory=list)
    _subdir: ClassVar[str] = "table_meta"

    def set(self, table_sizes: TableSizes, table_pos_arrays: TablePosArrays):
        self.table_sizes = list(table_sizes)
        self.table_positions = [
            array.tolist()
            for array in table_pos_arrays
            if isinstance(array, np.ndarray)
        ]


class SequentialPool(Executor):
    def __init__(self, max_workers=None) -> None:
        if max_workers != 1:
            raise ValueError("Do not use this class for concurrent execution.")

    # submit = operator.call   # only in Python 3.11+
    def submit(self, func, *args, **kwargs):
        future = Future()
        try:
            result = func(*args, **kwargs)
        except Exception as exc:
            future.set_exception(exc)
        else:
            future.set_result(result)

        return future


def make_executor(jobs: int) -> Executor:
    Pool: Type[Executor]

    if jobs == 1:
        max_workers: "int | None" = 1
        Pool = SequentialPool
    else:
        from concurrent.futures import ProcessPoolExecutor as Pool

        max_workers = None if jobs < 1 else jobs

    return Pool(max_workers)  # type:ignore[call-arg]


def all_file_paths(output_path: Path, subdir, suffix):
    yield from (
        path_root / file
        for root, _, files in os.walk(output_path)
        for file in files
        if (path_root := Path(root)).name == subdir and file.endswith(suffix)
    )


all_statistics_paths = partial(all_file_paths, subdir="statistics", suffix=".json")
all_probablities_paths = partial(
    all_file_paths, subdir="probablities", suffix=".parquet"
)
all_table_meta_paths = partial(all_file_paths, subdir="table_meta", suffix=".json")


def digitize_book(
    path_file: Path,
    first_date: str,
    last_date: str,
    size_cell: tuple[float, float, float, float] = (
        1.0,
        1.0,
        1.0,
        1.0,
    ),  # left, right, bottom, top
    first_page: Annotated[
        int,
        typer.Option(
            "-f", "--first-page", help="the page number corresponding to first_date"
        ),
    ] = 0,
    last_page: Annotated[
        int,
        typer.Option(
            "-l", "--last-page", help="the page number corresponding to last_date"
        ),
    ] = 0,
    page_middle: Annotated[
        int,
        typer.Option(
            "-m",
            "--page-middle",
            help="X coordinate of middle of page to help the rotation correction",
        ),
    ] = -1,
    table_fmt_dir: Path = Path("table_formats"),
    model_path: Path = Path(
        "/local_disk", "data", "ai-for-obs", "processed", "dawsonia_model_2022-12-19"
    ),
    prob_thresh: float = 0.8,
    output_path: Path = Path("output", "digitized"),
    output_text_fmt: bool = False,
    jobs: Annotated[
        int,
        typer.Option(
            help=(
                "parallel jobs over pages in the book (default: max workers in the"
                " system)"
            )
        ),
    ] = -1,
    verbose: bool = False,
    config: Annotated[Path, typer.Option(*config_cli_names, **config_kwargs)] = Path(
        "dawsonia.toml"
    ),
):  # pylint: disable=unused-argument, too-many-arguments, too-many-locals
    """Digitize PDF / ZARR into a dataframe using a trained ML model and
    write it out."""
    model_path = model_path.expanduser()
    output_path = output_path.expanduser()

    first_page, last_page, book = read_book(
        path_file,
        first_page,
        last_page,
        None if page_middle < 0 else page_middle,
        size_cell=list(size_cell),
        table_fmt_dir=table_fmt_dir,
    )

    table_fmt = book.table_format

    output_path_book = output_path / book.station_name / path_file.stem
    output_path_book.mkdir(exist_ok=True, parents=True)
    (output_path_book / "probablities").mkdir(exist_ok=True)

    date_range = pd.date_range(first_date, last_date, freq="D")
    init_data: list[dict[str, NDArray]] = [
        {
            key: np.empty(len(table_fmt.rows), dtype="O")
            for key in table_fmt.columns[table_idx]
        }
        for table_idx in table_fmt.preproc.idx_tables_size_verify
    ]

    # FIXME first page last and date_range may not be similar sizes?
    futures = []
    logger.info(f"Digitizing {book}")

    # TODO: check if this compatible with Pool
    from dawsonia.ml import ml

    with make_executor(jobs) as pool:
        if not DAWSONIA_DEBUG_DIGITIZE:
            submit = pool.submit
        else:
            import pdb

            submit = pdb.runcall  # type:ignore[assignment]

        for page_number, date in zip(range(first_page, last_page), date_range):
            date_str = date.strftime(r"%Y-%m-%d")
            output_path_page = output_path_book / date_str
            if verbose:
                logger.info(f"Writing {output_path_page}")

            futures.append(
                submit(
                    digitize_page_and_write_output,
                    book,
                    init_data,
                    page_number,
                    date_str,
                    model_path,
                    ml.model_predict,
                    prob_thresh,
                    output_path_page,
                    output_text_fmt,
                    DAWSONIA_DEBUG_DIGITIZE,
                )
            )

    from concurrent.futures import as_completed

    for future in as_completed(futures):
        if verbose:
            page_number, date_str, output_stats = future.result()
            logger.info(f"{page_number = } {date_str = }")
            logger.info(f"{output_stats = }")
        else:
            future.result()


def digitize_page_and_write_output(
    book: Book,
    init_data: list[dict[str, NDArray]],
    page_number: int,
    date_str: str,
    model_path: Path,
    model_predict: Callable,
    prob_thresh: float,
    output_path_page: Path,
    output_text_fmt: bool,
    debug: bool,
) -> tuple[int, str, Statistics]:
    """Read page from book, load model, run model prediction and write result to
    filesystem.

    """
    output_stats = Statistics()
    table_metadata = TableMetadata()
    try:
        image_page, table_pos_arrays, table_sizes = book.page_and_tables(page_number)
    except IndexError:
        output_stats.to_json(output_path_page)
        table_metadata.to_json(output_path_page)
        return page_number, date_str, output_stats

    # TODO: option to save it only if tables were not detected?
    Page(image_page).to_image(output_path_page)

    tokenizer = init_tokenizer()
    # TODO: see if loading model once, outside of concurrent.futures pool, is possible
    model = load_model(model_path, vocab_size=tokenizer.vocab_size)
    predictor = partial(model_predict, tokenizer=tokenizer, model=model)

    index_column = pd.Series(book.table_format.rows, name=book.table_format.name_idx)
    store_results = [index_column]
    store_probablities = [index_column]

    # NOTE: only labelling first two tables
    for table_idx in book.table_format.preproc.idx_tables_size_verify:
        # fmt: off
        if (
            (table_pos_array := table_pos_arrays[table_idx]) is not MarkArray.EMPTY and
            len(table_size := table_sizes[table_idx]) == 2
        ):
        # fmt: on
            results, probablities = digitize_table_with_model(
                book,
                predictor,
                image_page,
                table_pos_array,
                table_size,
                init_data[table_idx],
                debug=debug,
            )
            output_stats.tables_detected += 1
            store_results.append(results)
            store_probablities.append(probablities)
        else:
            logger.warning(f"Table {table_idx} in {page_number = } was not detected")

    df_results = pd.concat(store_results, axis=1).set_index(book.table_format.name_idx)
    df_probablities = pd.concat(store_probablities, axis=1).set_index(
        book.table_format.name_idx
    )

    output_stats.compute(df_results, df_probablities, prob_thresh)
    output_stats.to_json(output_path_page)

    table_metadata.set(table_sizes, table_pos_arrays)
    table_metadata.to_json(output_path_page)

    if output_text_fmt:
        output_table = df_results.to_markdown()
        output_path_page.with_suffix(".md").write_text(
            f"## {page_number}: {date_str}\n\n{output_table}"
        )
    else:
        path_result = output_path_page.with_suffix(".parquet")
        df_results.to_parquet(path_result)
        df_probablities.to_parquet(
            path_result.parent / "probablities" / path_result.name
        )

    return page_number, date_str, output_stats


@lru_cache
def init_tokenizer():
    """Tokenizer for the ML model"""
    from dawsonia.ml import ml

    return ml.Tokenizer(chars=ml.CHARSET_BASE, max_text_length=ml.MAX_TEXT_LENGTH)


@lru_cache
def load_model(
    model_path: Path, vocab_size: int, source: str = "washington", arch: str = "flor"
) -> "dawsonia.ml.ml.HTRModel":
    """Load checkpoint and initialize ML Model"""
    checkpoint_path = model_path / "output" / source / arch / "checkpoint_weights.hdf5"

    from dawsonia.ml import ml

    model = ml.make_htr_model(
        arch,
        checkpoint_path,
        vocab_size=vocab_size,
        top_paths=10,
    )
    return model


def digitize_table_with_model(
    book: Book,
    predictor: Callable[[NDArray], tuple[Prediction, Probability]],
    image_page: NDArray,
    table_pos_array: NDArray,
    table_size: tuple[int, int],
    init_data: dict[str, NDArray],
    row_start: int = 0,
    col_start: int = 0,
    debug: bool = False,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Digitize table cell-by-cell by using the callback function `predictor`."""
    nb_rows, nb_cols = table_size
    df_results = pd.DataFrame(init_data)
    df_probalities = pd.DataFrame(init_data)
    columns = df_results.columns
    # TODO: batch predict by passing a generator
    for row in range(nb_rows):
        for col in range(nb_cols):
            image_cell = book.crop_image_to_cell(image_page, table_pos_array, row, col)

            predict, probablities = predictor(image_cell)
            # NOTE: now we keep all values and not since we want to see the probablities
            # try:
            #     check_probability_thresh(predict[0], probablities[0], debug)
            # except PredictionError as err:
            #     if debug:
            #         logger.warning(repr(err))
            #     continue

            df_results[columns[col_start + col]][row_start + row] = predict[0][0].strip(
                "n"
            )
            df_probalities[columns[col_start + col]][row_start + row] = float(
                probablities[0][0]
            )

    return df_results, df_probalities


def check_probability_thresh(
    predict, probablities, debug, err_threshold=80, prob_diff_warn_threshold=50
):
    """Check if the first prediction is within warning threshold"""
    if (prob := probablities[0] * 100) < err_threshold:
        raise PredictionError(
            f"Model {predict[0]=} probabilty {prob}% is less than {err_threshold=}"
        )

    if (
        abs(probablities[0] - probablities[1]) * 100 < prob_diff_warn_threshold
        and debug
    ):
        logger.warning(
            f"Model produced {predict[0]=} and {predict[1]=} with similar "
            "probablities. Model appears to be confused. "
        )


app = typer.Typer()
app.callback(invoke_without_command=True)(digitize_book)


if __name__ == "__main__":
    digitize_book(
        Path(
            "/local_disk/data/ai-for-obs/raw/BJURÖKLUBB",
            "DAGBOK_Bjuröklubb_Station_Jan-Dec_1927.pdf",
        ),
        "1927-1-5",
        "1927-1-6",
        first_page=7,
    )
