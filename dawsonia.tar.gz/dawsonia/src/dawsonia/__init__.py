"""Plasndlansdln"""
import os
import logging
from dawsonia.log import init_logger
from dawsonia._version import __version__  # noqa


DAWSONIA_DEBUG = bool(os.getenv("DAWSONIA_DEBUG", 0))

init_logger("dawsonia", level=logging.DEBUG if DAWSONIA_DEBUG else logging.INFO)
