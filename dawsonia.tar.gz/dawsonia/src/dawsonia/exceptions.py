class PredictionError(ValueError):
    """Custom exception for model prediction errors"""

    pass
