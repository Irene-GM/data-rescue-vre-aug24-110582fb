# pylint: skip-file
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from functools import lru_cache

import numpy as np
import skimage
import skimage.morphology as morph
from numpy.typing import NDArray
from scipy.ndimage import rotate
from skimage import filters

from dawsonia.table_detect.opencv_contours import (
    table_detect_opencv_contours,
)
from dawsonia.table_detect.scipy_proj import table_detect_scipy_proj

from .typing import (
    PreprocConfig,
    PreprocMethods,
    TablePositions,
    TableSizes,
)
from .viz import (
    debug_image,
    debug_threshold,
)

logger = logging.getLogger(__name__)


@dataclass
class Preprocessor:
    disks: dict[int, NDArray[np.uint8]] = field(
        repr=False, default_factory=lambda: {size: morph.disk(size) for size in (3, 6)}
    )
    square: dict[int, NDArray[np.uint8]] = field(
        repr=False,
        default_factory=lambda: {size: morph.square(size) for size in (3, 10)},
    )

    @staticmethod
    @lru_cache
    def _mask_x(size) -> NDArray[np.uint8]:
        return np.ones((1, size), dtype=np.uint8)

    @staticmethod
    @lru_cache
    def _mask_y(size) -> NDArray[np.uint8]:
        return np.ones((size, 1), dtype=np.uint8)

    def preprocess(
        self,
        size_tables: tuple[tuple[int, int], ...],
        preproc_cfg: PreprocConfig,
        middle: int | None,
        image: NDArray[np.int16],
    ) -> tuple[NDArray[np.uint8], TablePositions, TableSizes]:
        """Preprocess image and perform table detection"""
        # image = np.sum(image, 2)  # convert to black and white
        image = skimage.color.rgb2gray(image)

        # remove background
        # dilation followed by erosion remove black letter of the page
        image_background = morph.closing(image, self.disks[6])
        image_filter = image - image_background  # remove background
        image_filter = image_filter - np.min(image_filter)  # normalize min=0

        if preproc_cfg.corr_rotate:
            # correction rotation image
            image_filter = corr_rotate(image_filter, middle=middle)
        else:
            image_filter = image_filter.astype(np.float32)

        og_image = np.copy(image_filter)

        ligne_filter = self.compute_ligne_filter(image_filter)

        # get position of cases for every tables
        debug_threshold(ligne_filter, "ligne_filter")
        ligne_filter_thresh = filters.threshold_otsu(ligne_filter)
        binary_line = ligne_filter > ligne_filter_thresh
        # increase size of line
        binary_line = morph.erosion(binary_line, self.square[10])

        if preproc_cfg.method == PreprocMethods.SCIPY_PROJ:
            l_position, l_size, success = table_detect_scipy_proj(
                binary_line,
                size_tables,
                preproc_cfg,
                original_image=og_image,
            )
        elif preproc_cfg.method == PreprocMethods.OPENCV_CONTOURS:
            l_position, l_size, success = table_detect_opencv_contours(
                # ligne_filter,
                # ligne_filter_thresh,
                ligne_filter_shorter := self.compute_ligne_filter(image_filter, 20),
                filters.threshold_otsu(ligne_filter_shorter),
                binary_line,
                size_tables,
                preproc_cfg,
                original_image=og_image,
            )
        else:
            raise ValueError(f"Unkown table detection method {preproc_cfg.method}")

        if success:
            image_final = self.compute_image_final(
                image_filter,
                ligne_filter,
                # morph.erosion(ligne_filter, self.square[3])
                # skimage.filters.median(ligne_filter, self.square[3])
                # np.where(binary_line, np.median(ligne_filter), ligne_filter),
            )
        else:
            image_final = (255 * image_filter / np.max(image_filter)).astype(np.uint8)

        return image_final, l_position, l_size

    def compute_ligne_filter(self, image_filter, mask_size=36):
        """Get lines of the table"""
        ligne_x = morph.closing(image_filter, self._mask_x(mask_size))
        ligne_y = morph.closing(image_filter, self._mask_y(mask_size))
        ligne = ligne_x + ligne_y

        ligne_background = morph.closing(ligne, self.disks[3])
        ligne_filter = ligne - ligne_background
        ligne_filter -= np.min(ligne_filter)
        debug_image(ligne_filter, "ligne_filter")

        return ligne_filter

    def compute_image_final(self, image_filter, ligne_filter):
        """Final image adjustment"""
        image_final = image_filter - ligne_filter
        image_final -= np.min(image_final)
        debug_image(image_final, "image_final sans lines and background")
        # image_final = image_filter
        # debug_image(image_final, "image_final <- image_filter")

        p2, p98 = np.percentile(image_final, (1, 99))
        # increase saturation
        image_final = skimage.exposure.rescale_intensity(
            image_final, in_range=(p2, p98)
        )
        image_final -= np.min(image_final)
        # normalize between 0 to 255
        image_final = (255 * image_final / np.max(image_final)).astype(np.uint8)
        debug_image(image_final, "compute_image_final")
        return image_final


def corr_rotate(image: NDArray, middle: int | None = None) -> NDArray[np.float32]:
    """rotate the image if necessary to align with the horizontal
     Parameters
     ----------
    image : array 2D
         grey image of a page
     Returns
     -------
     im : array 2D (bigger)
         image but alligned and with more white margins on the sides and in the middle

    """
    image = np.max(image) - image
    image = image.astype(np.float32)

    debug_image(image, "corr_rotate: begin")
    debug_threshold(image, "corr_rotate")

    thresh = filters.threshold_otsu(image)
    binary = image > thresh
    shape_im = image.shape
    if middle is not None:
        MIDDLE = middle
    else:
        MIDDLE = shape_im[1] // 2  # FIXME: Not good enough, needs improvement.

    # Split image into two
    im1 = image[:, :MIDDLE]
    im2 = image[:, MIDDLE:]
    binary_top_left = binary[: shape_im[0] // 4, : shape_im[1] // 2]
    binary_top_right = binary[: shape_im[0] // 4, shape_im[1] // 2 :]
    shape_im1 = im1.shape
    shape_im2 = im2.shape
    angles = [(k - 10) / 4 for k in range(20)]
    best_1 = 0.0
    best_2 = 0.0
    maxx1 = 0
    for angle in angles:
        rotated = rotate(binary_top_left, angle)
        maxx2 = np.std(np.sum(rotated, 1))
        if maxx2 >= maxx1:
            maxx1 = maxx2
            best_1 = angle
    maxx1 = 0
    for angle in angles:
        rotated = rotate(binary_top_right, angle)
        maxx2 = np.max(np.sum(rotated, 1))
        if maxx2 >= maxx1:
            maxx1 = maxx2
            best_2 = angle
    im1 = rotate(im1, best_1)[: shape_im1[0], -shape_im1[1] :]
    im2 = rotate(im2, best_2)[: shape_im2[0], -shape_im2[1] :]

    # FIXME: should we add a margin as shown below?

    # shape_im1 = im1.shape
    # shape_im2 = im2.shape
    # MARGIN = 30  # margin size
    # im1_middle_marge = np.ones(
    #     (shape_im1[0] + MARGIN * 2, shape_im1[1] + MARGIN * 2)
    # ) * np.max(image)
    # im1_middle_marge[MARGIN:-MARGIN, MARGIN:-MARGIN] = im1
    # im2_middle_marge = np.ones(
    #     (shape_im2[0] + MARGIN * 2, shape_im2[1] + MARGIN * 2)
    # ) * np.max(image)
    # im2_middle_marge[MARGIN:-MARGIN, MARGIN:-MARGIN] = im2
    im = np.concatenate((im1, im2), 1)
    im = np.max(im) - im
    debug_image(im, "corr_rotate: end")
    return im
