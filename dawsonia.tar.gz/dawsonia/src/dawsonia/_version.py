"""Version of package dawsonia. Follows semver."""

__version__ = "0.1.0b0"
