from __future__ import annotations

import logging
import uuid
from pathlib import Path
from typing import Iterable, Literal

import cv2
import numpy as np
import skimage
import skimage.morphology as morph
from numpy.typing import ArrayLike, NDArray
from scipy.ndimage import label
from scipy.optimize import curve_fit
from sklearn.cluster import AgglomerativeClustering

from dawsonia.table_detect.utils import (
    all_size_tables_match,
    any_size_tables_match,
    table_modif_rm_row_col,
)
from dawsonia.typing import (
    BBoxTuple,
    ClusterLabel,
    PreprocConfig,
    TablePositions,
    TableSizes,
)
from dawsonia.viz import (
    DAWSONIA_DEBUG_TABLE_DETECT,
    debug_clustered_bboxes,
    debug_image,
    debug_image_table_detect_opencv_contours,
    debug_tables_detected,
)

logger = logging.getLogger(__name__)
if DAWSONIA_DEBUG_TABLE_DETECT:
    log_table_detect = logger.info
else:
    log_table_detect = logger.debug


def table_detect_opencv_contours(
    filtered_image: NDArray,
    thresh_value: NDArray,
    binary_tables: NDArray[np.bool_],
    size_tables: TableSizes,
    preproc_cfg: PreprocConfig,
    original_image: NDArray,
) -> tuple[TablePositions, TableSizes, int]:

    filtered_image_inv = skimage.util.invert(  # type: ignore
        skimage.exposure.rescale_intensity(filtered_image, out_range="uint8")  # type: ignore
    )
    # _, thresh_value = cv2.threshold(filtered_image_inv_thresh, 180, 255, cv2.THRESH_BINARY_INV)

    # minimum number of pixels that a labelled array must have to be considered
    # as a table
    MIN_NB_PIXELS = 15_000
    L_SENSIBILITY = (
        1.05,
        # 1.0,
        # 0.95,
    )
    NB_TABLES = max(5, len(preproc_cfg.idx_tables_size_verify))
    list_sizes: TableSizes = [[] for _ in range(NB_TABLES)]
    list_positions: TablePositions = [[] for _ in range(NB_TABLES)]

    # inverse image and separate non connected objects
    # TODO: construct binary_tables from filtered_image_inv_thresh?
    label_tables, nb_labels = label(~binary_tables)
    debug_tables_detected(binary_tables, label_tables, MIN_NB_PIXELS)

    for sensibility in L_SENSIBILITY:
        get_table_structure(
            size_tables,
            preproc_cfg,
            filtered_image,
            filtered_image_inv,
            thresh_value,
            original_image,
            label_tables,
            nb_labels,
            MIN_NB_PIXELS,
            sensibility,
            list_sizes,
            list_positions,
        )
        if success := all_size_tables_match(list_sizes, size_tables, preproc_cfg):
            break
    else:
        success = any_size_tables_match(list_sizes, size_tables, preproc_cfg)

    return list_positions, list_sizes, success


def get_table_structure(
    expected_size_tables: TableSizes,
    preproc_cfg: PreprocConfig,
    filtered_image: NDArray,
    filtered_image_inv: NDArray,
    thresh_value: NDArray,
    original_image: NDArray,
    label_tables: NDArray[np.int64],
    nb_labels: int,
    min_nb_pixels: int,
    sensibility: float,
    list_sizes: TableSizes,
    list_positions: TablePositions,
) -> None:
    # Inverse image thresholding
    filtered_image_inv_thresh = np.where(
        filtered_image < sensibility * thresh_value, filtered_image_inv, 0
    )

    dilated_value = morph.dilation(filtered_image_inv_thresh, morph.square(5))
    # kernel = np.ones((5, 5), np.uint8)
    # dilated_value = cv2.dilate(filter_image_inv_thresh, kernel, iterations=1)

    l_size = []  # size of a table
    list_pos = []  # list of bboxes for each table
    list_pos_tab = []  # position of the first bbox / corner of the table

    for k in range(1, nb_labels + 1):  # for every objects detected
        mask = label_tables == k

        if (table_nb_pixels := np.where(mask)[0].size) < min_nb_pixels:
            continue

        log_table_detect(f"Finding contours for a mask with {table_nb_pixels=}")

        contours, hierarchy = cv2.findContours(
            np.where(mask, dilated_value, 0),
            cv2.RETR_LIST,
            # cv2.RETR_TREE,
            # cv2.CHAIN_APPROX_NONE
            cv2.CHAIN_APPROX_SIMPLE,
        )
        if not contours:
            log_table_detect("No contours detected!")
            continue

        bboxes = bboxes_from_contours(contours)
        if not bboxes:
            log_table_detect("No bboxes detected!")
            continue

        debug_image(original_image, "table_detect_opencv_contours")
        debug_image_table_detect_opencv_contours(
            filtered_image,
            filtered_image_inv_thresh,
            dilated_value,
            original_image,
            bboxes,
        )

        # apply hierarchical agglomerative clustering to the coordinates

        row_labels = np.array([])
        column_labels = np.array([])
        try:
            # NOTE: loop with different distance_threshold as we do with
            # sensibility in the SCIPY_PROJ method

            # cluster with x coords to get columns
            for distance_factor in range(1, 4):
                column_labels, column_bboxes_idxs = cluster_axis(
                    dilated_value, bboxes, 0, 24 * distance_factor
                )
                # TODO: should we aim for clustering most of the bboxes?
                if column_labels.size:
                    break

            # cluster with y coords to get rows
            for distance_factor in range(1, 4):
                row_labels, row_bboxes_idxs = cluster_axis(
                    dilated_value, bboxes, 1, 16 * distance_factor
                )
                if row_labels.size:
                    break

        except ValueError as err:
            logger.exception(err)
            logger.error(
                f"Encountered error in AgglomerativeClustering with {bboxes = }."
            )
            continue

        if not row_labels.size or not column_labels.size:
            logger.error(
                f"One or more of the AgglomerativeClustering failed with {bboxes = }"
                f"{row_labels = }\n"
                f"{column_labels = }\n"
            )
            continue

        all_bboxes = create_bbox_array(
            bboxes, column_labels, column_bboxes_idxs, row_labels, row_bboxes_idxs
        )

        detected_size = all_bboxes.shape[:2]
        detected_positions = all_bboxes.reshape((-1, 4))

        l_size.append(detected_size)
        list_pos.append(detected_positions)
        list_pos_tab.append(tuple(all_bboxes[0, 0, :2]))

        if DAWSONIA_DEBUG_TABLE_DETECT:
            import joblib

            local_vars = (
                "bboxes",
                "column_labels",
                "column_bboxes_idxs",
                "row_labels",
                "row_bboxes_idxs",
                "original_image",
            )
            joblib_file = Path.cwd() / f"get_table_structure_{uuid.uuid1()}.joblib"
            joblib.dump(
                {k: v for k, v in locals().items() if k in local_vars}, joblib_file
            )
            log_table_detect(
                f"Dumped {local_vars} into {joblib_file}. Explore it using"
                " get_table_strucutre_interpolation.ipynb"
            )

    array_pos_tab = np.array(list_pos_tab, dtype=[("x", "<f8"), ("y", "<f8")])
    ordering = np.argsort(array_pos_tab, order=("x", "y"))

    l_size = np.array(l_size)[ordering].tolist()
    # ragged list of arrays, cannot be converted to numpy
    list_pos = [list_pos[int(i)] for i in ordering]

    if len(l_size) > len(expected_size_tables):
        raise NotImplementedError("Too many tables detected")

    if preproc_cfg.table_modif:
        logger.info("Preproc: applying table_modif_rm_row_col")
        l_size, list_pos = table_modif_rm_row_col(
            l_size,
            list_pos,
            expected_size_tables,
            preproc_cfg.idx_tables_size_verify,
        )

    for i_table, detected_size in enumerate(l_size):
        if (detected_size == expected_size_tables[i_table]) and not list_sizes[i_table]:
            log_table_detect(f"saving table {i_table}")
            list_sizes[i_table] = detected_size
            list_positions[i_table] = detected_positions


def create_bbox_array(
    bboxes: list[BBoxTuple],
    column_labels: ArrayLike[ClusterLabel],
    column_bboxes_idxs: dict[ClusterLabel, NDArray[np.int64]],
    row_labels: ArrayLike[ClusterLabel],
    row_bboxes_idxs: dict[ClusterLabel, NDArray[np.int64]],
):
    bbox_arr = np.array(bboxes)
    # list_rows = [bbox_arr[row_bboxes_idxs[row_label]] for row_label in row_labels]

    nb_rows = row_labels.size
    # nb_cols = max(arr.shape[0] for arr in list_rows)
    nb_cols = column_labels.size

    does_not_need_fixing = bbox_arr.size == nb_rows * nb_cols * 4

    if does_not_need_fixing:
        logger.debug(f"No fixing required for table of size {nb_rows, nb_cols}")
        bbox_arr = np.array(sorted(bboxes))
        bbox_arr = bbox_arr.reshape((nb_rows, nb_cols, 4))
        return bbox_arr

    # 3D array
    all_bboxes = np.empty((nb_rows, nb_cols, 4), dtype=float)
    all_bboxes[...] = np.nan

    # for i, row in enumerate(list_rows):
    #     all_rows[i, : row.shape[0]] = row

    for i, row_label in enumerate(row_labels):
        for j, column_label in enumerate(column_labels):
            bbox_idx: set[int] = set(row_bboxes_idxs[row_label]).intersection(
                column_bboxes_idxs[column_label]
            )
            if not bbox_idx:
                continue
            elif len(bbox_idx) != 1:
                logger.warning("Multiple cells found at row-column intersection.")

            bbox = bbox_arr[bbox_idx.pop()]
            # FIXME: Compare bbox width and height to
            # column's width_median and rows's height median
            # and discard it.
            all_bboxes[i, j, :] = bbox

    set_nan_to_odd_bboxes(all_bboxes)
    fixed_bboxes = fix_missing_bboxes(all_bboxes)
    return fixed_bboxes


def set_nan_to_odd_bboxes(all_bboxes):
    factor_s = 0.7
    factor_l = 1.3

    width = all_bboxes[..., 2]
    width_median = np.nanmedian(width, axis=0)

    height = all_bboxes[..., 3]
    height_median = np.nanmedian(height, axis=1)

    small_width = width < width_median * factor_s
    large_width = width > width_median * factor_l

    small_height = (height.T < height_median * factor_s).T
    large_height = (height.T > height_median * factor_l).T

    all_bboxes[small_width | large_width | small_height | large_height] = np.nan


def fix_missing_bboxes(all_bboxes):
    xs = all_bboxes[..., 0]
    xs_median = np.nanmedian(xs, axis=0)

    ys = all_bboxes[..., 1]
    ys_median = np.nanmedian(ys, axis=1)

    width = all_bboxes[..., 2]
    width_median = np.nanmedian(width, axis=0)

    height = all_bboxes[..., 3]
    height_median = np.nanmedian(height, axis=1)

    nan_rows_idxs, nan_cols_idxs, _ = np.where(np.isnan(all_bboxes))

    # Naive fix with medians.
    # naive_fix_bboxes = all_bboxes.copy()
    # naive_fix_bboxes[nan_rows_idxs, nan_cols_idxs, 0] = xs_median[nan_cols_idxs]
    # naive_fix_bboxes[nan_rows_idxs, nan_cols_idxs, 1] = ys_median[nan_rows_idxs]
    # naive_fix_bboxes[nan_rows_idxs, nan_cols_idxs, 2] = width_median[nan_cols_idxs]
    # naive_fix_bboxes[nan_rows_idxs, nan_cols_idxs, 3] = height_median[nan_rows_idxs]

    # xs and ys are corrected using curve-fitting here
    nan_mask = ~np.isnan(all_bboxes[..., 0])

    # select a candidate row with least number of nans
    try:
        sel_row = nan_mask.sum(axis=1).argmax()
    except ValueError:
        breakpoint()
    xs_sel_row = all_bboxes[sel_row, :, 0][nan_mask[sel_row]]
    ys_sel_row = all_bboxes[sel_row, :, 1][nan_mask[sel_row]]

    def page_curvature_trial_x_cubic(x, a0, a1, a2, a3):
        return ys_median[sel_row] + a0 + a1 * x + a2 * x**2 + a3 * x**3

    try:
        popt, _ = curve_fit(page_curvature_trial_x_cubic, xs_sel_row, ys_sel_row)
    except (TypeError, ValueError) as err:
        # def page_curvature_trial_x_quad(x, a0, a1, a2):
        #     return ys_median[sel_row] + a0 + a1 * x + a2 * x**2

        # popt, _ = curve_fit(page_curvature_trial_x_quad, xs_sel_row, ys_sel_row)
        # page_curvature_along_x = page_curvature_along_x_quad
        logger.error(
            f"Error occured while attempting to curve fit with {xs_sel_row.size} data"
            " points. Defaulting to median value..."
        )
        logger.error(repr(err))
        ys_median_at_nans = ys_median[nan_rows_idxs]
    else:
        ys_median_at_nans = page_curvature_along_x_cubic(
            xs_median[nan_cols_idxs], ys_median[nan_rows_idxs], *popt
        )

    fixed_bboxes = all_bboxes.copy()
    # FIXME: instead of using xs_median, it can also be corrected by computing a page_curvature_along_y function
    fixed_bboxes[nan_rows_idxs, nan_cols_idxs, 0] = xs_median[nan_cols_idxs]
    fixed_bboxes[nan_rows_idxs, nan_cols_idxs, 1] = ys_median_at_nans
    fixed_bboxes[nan_rows_idxs, nan_cols_idxs, 2] = width_median[nan_cols_idxs]
    fixed_bboxes[nan_rows_idxs, nan_cols_idxs, 3] = height_median[nan_rows_idxs]
    return fixed_bboxes


# TODO: find a criterion to switch to quadratic curve fitting
def page_curvature_along_x_quad(xs, y_median, a0, a1, a2):
    """A quadratic polynomial with coefficients. Coefficients should be determined by curve-fitting"""
    return y_median + a0 + a1 * xs + a2 * xs**2


def page_curvature_along_x_cubic(xs, y_median, a0, a1, a2, a3):
    """A cubic polynomial with coefficients. Coefficients should be determined by curve-fitting"""
    return y_median + a0 + a1 * xs + a2 * xs**2 + a3 * xs**3


def bboxes_from_contours(
    contours,
    # TODO:  make these tunable parameters:
    area_range=(300, 10_000),
    aspect_ratio_range=(0.05, 20),
):
    aspect_ratio_min, aspect_ratio_max = aspect_ratio_range
    bboxes: list[BBoxTuple] = []

    for cnt in contours:
        xp, yp, xl, yl = cv2.boundingRect(cnt)
        bbox = BBoxTuple((xp, yp, xl, yl))

        # bounding the images
        if int(_area := cv2.contourArea(cnt)) not in range(*area_range):
            ...
            # log_table_detect(f"Discarding bad {area = }: {bbox = }")
        elif not (aspect_ratio_min < (_aspect_ratio := xl / yl) < aspect_ratio_max):
            ...
            # log_table_detect(f"Discarding weird {aspect_ratio = }: {bbox = }")
        else:
            # Process the contour
            # logger.info(f"Detected contour of {(x, y, w, h) =}")
            # original_image = cv2.rectangle(
            #     original_image, (x, y), (x + w, y + h), (0, 0, 255), 1
            # )
            bboxes.append(bbox)
    return bboxes


def cluster_axis(
    ref_image: NDArray,
    bboxes: Iterable[BBoxTuple],
    axis: Literal[0, 1] = 0,
    distance_threshold: float | None = None,
    min_cluster_size: int = 0,
) -> tuple[ArrayLike[ClusterLabel], dict[ClusterLabel, NDArray[np.int64]]]:
    """Cluster bboxes along `axis`.

    Parameters
    ----------
    ref_image: NDArray
        Image for debugging

    bboxes: Iterable[BBoxTuple]
        Bounding boxes to be clustered

    axis: int
        Axis along which clustering should be done. 0 identifies columns and 1 identifies rows

    distance_threshold: float | None
        Max. distance in pixels between bbox centers within a cluster.
        It is the linkage distance threshold and above this clusters will not be merged.

    min_cluster_size: int
        Minimum number of bounding bboxes to be considered a cluster

    Notes
    -----
    Reference for this method can be found at
    <https://pyimagesearch.com/2022/02/28/multi-column-table-ocr/>.
    See also {class}`sklearn.cluster.AgglomerativeClustering`.
    """
    axis_other = int(not axis)

    xp_bboxes = np.array([(bbox[axis], 0) for bbox in bboxes])

    # For x-axis, span == width; for y-axis, span == height
    span_idx = axis + 2
    span_bboxes = np.array([(bbox[span_idx], 0) for bbox in bboxes])

    center_bboxes = xp_bboxes + span_bboxes / 2

    if not distance_threshold:
        from statistics import median

        distance_threshold = median(span_bboxes[0, :])
        logger.info(f"Setting agglomerative cluster {distance_threshold = }")

    clustering = AgglomerativeClustering(
        n_clusters=None,
        metric="manhattan",
        linkage="complete",
        distance_threshold=distance_threshold,
    )
    clustering.fit(center_bboxes)

    valid_clusters: list[ClusterLabel] = []
    coords_axis: list[np.floating] = []
    for cluster_label in set(clustering.labels_):
        # extract the indexes for the coordinates belonging to the
        # current cluster
        cluster_bbox_idxs = np.where(clustering.labels_ == cluster_label)[0]

        # verify that the cluster is sufficiently large
        if cluster_bbox_idxs.size > min_cluster_size:
            # compute the average x-coordinate value of the cluster and
            # update our clusters list with the current label and the
            # average x-coordinate
            avg = np.average([bboxes[i][axis] for i in cluster_bbox_idxs])
            coords_axis.append(avg)
            valid_clusters.append(cluster_label)

    # sort the clusters by their average x-coordinate and initialize our array
    sorted_clusters = np.array(valid_clusters)[np.argsort(coords_axis)]

    # loop over the clusters again, this time in sorted order
    # save the results in a dictionary
    sorted_cluster_bboxes_idxs: dict[ClusterLabel, NDArray[np.int64]] = {}

    for cluster_label in sorted_clusters:
        # extract the indexes for the coordinates belonging to the
        # current cluster
        cluster_bbox_idxs = np.where(clustering.labels_ == cluster_label)[0]
        # extract the y-coordinates from the elements in the current cluster
        coords_axis_other = [bboxes[i][axis_other] for i in cluster_bbox_idxs]
        # then sort the bboxes based on the coordinates from top-to-bottom
        cluster_bbox_idxs = cluster_bbox_idxs[np.argsort(coords_axis_other)]

        sorted_cluster_bboxes_idxs[cluster_label] = cluster_bbox_idxs

    log_table_detect(f"cluster labels = {sorted_clusters}")
    debug_clustered_bboxes(ref_image, bboxes, sorted_cluster_bboxes_idxs)

    # TODO: do we need to assign labels if only one bbox was detected in a column or does min_cluster_size works
    return sorted_clusters, sorted_cluster_bboxes_idxs
