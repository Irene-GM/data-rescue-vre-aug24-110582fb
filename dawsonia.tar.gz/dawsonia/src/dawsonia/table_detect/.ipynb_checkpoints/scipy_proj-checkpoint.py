import logging

import numpy as np
from numpy.typing import NDArray
from scipy import signal
from scipy.ndimage import label

from dawsonia.table_detect.utils import (
    all_size_tables_match,
    any_size_tables_match,
    table_modif_rm_row_col,
)
from dawsonia.typing import PreprocConfig, TablePositions, TableSizes
from dawsonia.viz import (
    DAWSONIA_DEBUG_TABLE_DETECT,
    debug_table_positions,
    debug_tables_detected,
)

logger = logging.getLogger(__name__)
if DAWSONIA_DEBUG_TABLE_DETECT:
    log_table_detect = logger.info
else:
    log_table_detect = logger.debug


def table_detect_scipy_proj(
    binary_tables: NDArray[np.bool_],
    size_tables,
    preproc_cfg: PreprocConfig,
    original_image,
) -> tuple[TablePositions, TableSizes, int]:
    """get position and size for every tables
    Parameters
    ----------
    binary_tables : array 2D
        binary image of an empty one-page table
    size_tables
        expected table dimensions
    only_top_table : boolean
        if True return only 2 first tables
    Returns
    -------
    list_pos3 : list
        Each element of this list is a list containing the informations of each
        box of a table. The format of the information is::

           [
                vertical position [int],
                horizontal position [int],
                width [int],
                height [int]
           ]

        the position is defined in relation to the position on the whole page
        and not in relation to the relative position of the table
    l_size3 : list
    list of size of tables (same order than list_pos3
    """
    # total expected number of tables
    NB_TABLES = max(5, len(preproc_cfg.idx_tables_size_verify))
    # minimum number of pixels that a labelled array must have to be considered
    # as a table
    MIN_NB_PIXELS = 15_000
    L_SENSIBILITY = (
        0.9,
        0.7,
        0.6,
        0.55,
        0.5,
        0.47,
        0.45,
        0.43,
        0.41,
        0.39,
        0.37,
        0.35,
        0.33,
        0.25,
        0.2,
    )
    # different sensitivities tested to obtain the right dimension of tables,
    # sensitivity of 1 means very little sensitive (detects no lines) and <1
    # lower sensitivity (detected more lines)

    l_size3: TableSizes = [[] for _ in range(NB_TABLES)]
    list_pos3: TablePositions = [[] for _ in range(NB_TABLES)]

    # inverse image and separate non connected objects
    label_tables, nb_labels = label(~binary_tables)
    debug_tables_detected(binary_tables, label_tables, MIN_NB_PIXELS)

    # list to contain projections of tables / connected features
    # with size more than MIN_NB_PIXELS
    projections_xy = projections_of_label_tables(label_tables, nb_labels, MIN_NB_PIXELS)

    success = 0

    for sensibility in L_SENSIBILITY:
        get_table_structure(
            size_tables,
            preproc_cfg,
            original_image,
            label_tables,
            projections_xy,
            sensibility,
            l_size3,
            list_pos3,
        )

        # If we only care about size of tables with index in idx_tables_size_verify
        if success := all_size_tables_match(l_size3, size_tables, preproc_cfg):
            break
    else:
        success = any_size_tables_match(l_size3, size_tables, preproc_cfg)

    if success:
        debug_table_positions(
            original_image, list_pos3, l_size3, label_tables, printer=False
        )
        # debug_table_positions(
        #     original_image, positions_detected, size_tables_detected, label_tables, printer=False
        # )

    return list_pos3, l_size3, success


def get_table_structure(
    expected_size_tables,
    preproc_cfg,
    original_image,
    label_tables,
    projections_xy,
    sensibility,
    l_size3,
    list_pos3,
) -> None:
    l_size = []  # size of a table
    list_pos = []  # list of bboxes for each table
    list_pos_tab = []  # position of the first bbox / corner of the table

    for proj_x, proj_y in projections_xy:  # for every table
        bin_proj_x = proj_x > int(np.max(proj_x) * sensibility)
        bin_proj_y = proj_y > int(np.max(proj_y) * sensibility)
        # we get position for projection
        x_pos, x_len = get_position(bin_proj_x)
        y_pos, y_len = get_position(bin_proj_y)

        # we combine data from projection to create data for all te tab
        tot = [
            (xp, yp, xl, yl)
            for xp, xl in zip(x_pos, x_len)
            for yp, yl in zip(y_pos, y_len)
        ]
        if tot:
            # if tab is not only on case
            list_pos.append(tot)
            list_pos_tab.append([tot[0][0], tot[0][1]])
            l_size.append([len(x_pos), len(y_pos)])

    list_pos_tab = simply_order(list_pos_tab)
    order = [3000 * pos_tab[0] + pos_tab[1] for pos_tab in list_pos_tab]

    list_pos = sort_insertion(list_pos, order)
    l_size = sort_insertion(l_size, order)

    if preproc_cfg.table_modif:
        l_size, list_pos = table_modif_rm_row_col(
            l_size, list_pos, expected_size_tables, preproc_cfg.idx_tables_size_verify
        )

    log_table_detect(f"with {sensibility = }: {l_size = }")

    if len(l_size) > len(expected_size_tables):
        # Discard duplicates
        debug_table_positions(
            original_image, list_pos, l_size, label_tables, printer=False
        )
        list_pos2 = []
        l_size2 = []
        for k, dim in enumerate(l_size):
            if dim in expected_size_tables:
                list_pos2.append(list_pos[k])
                l_size2.append(dim)
        list_pos2 = list_pos2[: len(expected_size_tables)]
        l_size2 = l_size2[: len(expected_size_tables)]
    else:
        list_pos2 = list_pos
        l_size2 = l_size

        # save only correct dimension tables in list_pos3 and l_size3
    for i_table, detected_size in enumerate(l_size2):
        if (detected_size == expected_size_tables[i_table]) and not l_size3[i_table]:
            log_table_detect(f"saving table {i_table}")
            l_size3[i_table] = detected_size
            list_pos3[i_table] = list_pos2[i_table]


def projections_of_label_tables(label_tables, nb_labels, min_nb_pixels):
    projections_xy = []
    nb_labels_pass = 0

    for k in range(1, nb_labels + 1):  # for every objects detected
        table_k_indices = np.where(label_tables == k)

        if table_k_indices[0].size > min_nb_pixels:
            nb_labels_pass += 1

            # if object are not to small in term of pixel
            # create a white image (dtype = int8 in order to reduce memory place)
            binary_table_mask = np.zeros_like(label_tables, dtype=np.int8)
            # add white element
            binary_table_mask[table_k_indices] = 1

            proj_x = np.sum(binary_table_mask, 1)  # projection_1
            proj_y = np.sum(binary_table_mask, 0)  # projection_2
            # sometime edge of tab don't appear, this code can create edge in this case:
            # proj_x = add_edge(proj_x)
            # proj_y = add_edge(proj_y)

            projections_xy.append((proj_x, proj_y))

    log_table_detect(f"Detected {nb_labels_pass = }")

    return projections_xy


def simply_order(tot_p):
    """simplify the position of tables to avoid random position.
    Parameters
    ----------
    tot_p : list
        list of position of every tables
    Returns
    -------
    tot_p : list
        list of position of every tables
        this list is ordered
    """
    equal1 = 0
    equal2 = 0
    # if there is rotation, an table can end up on top of another in some case,
    # this value takes this uncertainty into account
    PRECISION = 100
    for i in range(len(tot_p) - 1):
        equal1 = tot_p[i][0]
        equal2 = tot_p[i][1]
        for j in range(i, len(tot_p)):
            if (equal1 + PRECISION > tot_p[j][0]) and (
                tot_p[j][0] > equal1 - PRECISION
            ):
                tot_p[j][0] = equal1
            if (equal2 + PRECISION > tot_p[j][1]) and (
                tot_p[j][1] > equal2 - PRECISION
            ):
                tot_p[j][1] = equal2
    return tot_p


def sort_insertion(L, LL):
    """Sort tables according to LL using Insertion Sort algorithm.
    Parameters
    ----------
    L : list
        same len than LL
    LL : list
        contains elements that can be sorted
    Returns
    -------
    L : list
        contains L sorted elements
    """
    L2 = np.copy(LL)
    N = len(L)
    for n in range(1, N):
        cle = L[n]
        cle2 = L2[n]
        j = n - 1
        while j >= 0 and L2[j] > cle2:
            L2[j + 1] = L2[j]  # decalage
            L[j + 1] = L[j]
            j = j - 1
        L2[j + 1] = cle2
        L[j + 1] = cle
    return L


# FIXME: should be possible to replace sort_insertion with something like
# but now it fails when the "array has an inhomogeneous shape after 1 dimensions.
# The detected shape was (18,) + inhomogeneous part."
# def sort_array(xs, order):
#     return np.array(xs)[np.argsort(order)]


def add_edge(proj: NDArray) -> NDArray:
    """Add the vertical or horizontal edges of a table
    Parameters
    ----------
    proj: array 1D
        horizontal or vertical projection of a binary table
    Returns
    -------
    proj : array 1D
        horizontal or vertical projection of a binary table, edge add with the
        max value
    """
    # edge is equal to false if we have not yet scanned the first element of the
    # table
    edge = False
    for k in range(1, len(proj) - 1):
        if not edge and proj[k] > 0 and proj[k - 1] < 1:
            # if we go from no tables to tables elements
            edge = True  # we detected edge
            proj[k] = np.max(proj)
            # if we go from elements to no more elements then we leave the table
            # and we can add an edge
        if edge and proj[k] > 0 and proj[k + 1] < 1:  # we add final edge
            proj[k] = np.max(proj)
    return proj


def _get_position_old(proj_x: NDArray) -> tuple[list[int], list[int]]:
    """determines the position of the maximums of a projection of an array (on x or y)
    therefore determine the position of the rows of a table

    Parameters
    ----------
    proj_x: array 1D
        horizontal or vertical projection of a binary table

    Returns
    -------
    x_pos : list of int
        list of position of the middle between 2 lines.
    x_len : list of int
        list of distance between line
    """
    len_x = 0
    MIN_VALUE = 20  # minimum distance to be considered as 2 different lines
    outside_table = True  # if not in the tab yet
    x_pos = []
    x_len = []
    for k in range(len(proj_x)):
        if (
            proj_x[k] == 0 and not outside_table
        ):  # if we are inside a table but not in a line
            len_x += 1
        if proj_x[k] == 1 and proj_x[k - 1] == 0:  # if we are in a line
            outside_table = False
            if len_x > MIN_VALUE:  # if the distance between 2 lines in not too small
                x_pos.append(k - len_x // 2)  # x_pos is te middle between 2 line
                x_len.append(len_x)
                len_x = 0
    # if x_pos:
    #     with open("get_pos_cases.toml", "a") as fp:
    #         print("[[cases]]", file=fp)
    #         print(f"{list(proj_x) = }", file=fp)
    #         print(f"{x_pos = }", file=fp)
    #         print(f"{x_len = }", file=fp)
    return x_pos, x_len


def get_position(xs: NDArray) -> tuple[NDArray, NDArray]:
    """Detect peaks or local maxima in `proj_x` to find positions of the rows in the
    table.

    Parameters
    ----------
    proj_x: array 1D
        horizontal or vertical projection of a binary table

    Returns
    -------
    x_pos : array 1D
        position of the middle between 2 lines.
    x_len : array 1D
        distance between line

    """
    # xs_trim_front = np.trim_zeros(xs, "f")
    # front_zero_pad = xs.size - xs_trim_front.size

    # Faster variant: because np.trim_zeros uses for-loops and we can do this because
    # xs is a boolean array
    front_zero_pad = xs.argmax()
    xs_trim_front = xs[front_zero_pad:]

    # FIXME: Make this a configurable parameter for compact tables
    MIN_VALUE = 20  # minimum distance to be considered as 2 different lines
    peaks, _ = signal.find_peaks(xs_trim_front, distance=MIN_VALUE)

    if peaks.size:
        peaks_left = np.roll(peaks, 1)
        peaks_left[0] = 0

        x_len = peaks - peaks_left
        x_pos = peaks - x_len // 2 + front_zero_pad
    else:
        x_pos = x_len = np.array([])

    return x_pos, x_len
