from __future__ import annotations

import logging
from typing import Literal, Sequence, TypeVar

import numpy as np

from dawsonia.typing import PreprocConfig

logger = logging.getLogger(__name__)

T = TypeVar("T")


def all_size_tables_match(
    size_tables_detected: Sequence[T],
    size_tables_expected: Sequence[T],
    preproc_cfg: PreprocConfig,
) -> Literal[2, 0]:
    if all(
        size_tables_detected[i_table] == size_tables_expected[i_table]
        for i_table in preproc_cfg.idx_tables_size_verify
    ):
        logger.info(f"🌞 final size of tables: {size_tables_detected}")
        return 2
    else:
        return 0


def any_size_tables_match(
    size_tables_detected: Sequence[T],
    size_tables_expected: Sequence[T],
    preproc_cfg: PreprocConfig,
) -> Literal[1, 0]:
    if any(
        size_tables_detected[i_table] == size_tables_expected[i_table]
        for i_table in preproc_cfg.idx_tables_size_verify
    ):
        logger.info(f"⛅ final size of tables: {size_tables_detected}")
        return 1
    else:
        logger.info("🌧 no tables found")
        return 0


def remove_row(l_size, size_tables, list_pos, n_table=0, nb_remove=1):
    copy = np.array(list_pos[n_table][:]).reshape(
        (l_size[n_table][0], l_size[n_table][1], 4)
    )

    copy2 = copy[nb_remove:, :, :].reshape(-1, 4)

    l_size[n_table][0] -= nb_remove
    list_pos[n_table] = copy2

    return list_pos, l_size


def remove_col(l_size, size_tables, list_pos, n_table=0, nb_remove=1):
    copy = np.array(list_pos[n_table][:]).reshape(
        (l_size[n_table][0], l_size[n_table][1], 4)
    )

    copy2 = copy[:, nb_remove:, :].reshape(-1, 4)

    l_size[n_table][1] -= nb_remove
    list_pos[n_table] = copy2

    return list_pos, l_size


def table_modif_rm_row_col(l_size, list_pos, size_tables, idx_tables_size_verify):
    # TODO: generalize number of rows etc to be removed
    nb_detected_tables = len(l_size)
    max_nb_verify = max(idx_tables_size_verify) + 1
    nb_tables_to_modify = min(nb_detected_tables, max_nb_verify)

    if nb_tables_to_modify > 0:
        list_pos, l_size = remove_col(
            l_size, size_tables, list_pos, n_table=0, nb_remove=1
        )  # Remove leading column
        list_pos, l_size = remove_row(
            l_size, size_tables, list_pos, n_table=0, nb_remove=2
        )  # Remove top row
    if nb_tables_to_modify > 1:
        list_pos, l_size = remove_row(
            l_size, size_tables, list_pos, n_table=1, nb_remove=2
        )  # Remove top two rows
    if nb_tables_to_modify > 3:
        list_pos, l_size = remove_col(
            l_size, size_tables, list_pos, n_table=3, nb_remove=1
        )
        list_pos, l_size = remove_row(
            l_size, size_tables, list_pos, n_table=3, nb_remove=1
        )
    if nb_tables_to_modify > 4:
        list_pos, l_size = remove_row(
            l_size, size_tables, list_pos, n_table=4, nb_remove=1
        )
    return l_size, list_pos
