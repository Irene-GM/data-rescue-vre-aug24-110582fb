import logging
import os
import sys


def init_logger_basic(name, level=logging.INFO):
    handler = logging.StreamHandler(sys.stdout)
    logging.basicConfig(handlers=[handler], level=level)

    os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"


def init_logger(name, level=logging.INFO, show_time=False, show_path=False):
    """Returns a logger instance using ``rich`` package if available; else
    defaults to ``logging`` standard library.

    """
    logger = logging.getLogger(name)

    try:
        from rich.logging import RichHandler

        handler = RichHandler(show_time=show_time, show_path=show_path)
    except ImportError:
        handler = logging.StreamHandler(sys.stdout)

    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )

    os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"
    # handler.setLevel(level)
    handler.setFormatter(formatter)

    logger.addHandler(handler)
    logger.setLevel(level)
