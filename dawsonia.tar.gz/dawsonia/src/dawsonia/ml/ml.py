"""NOTE:
Provides options via the command line to perform project tasks.
* `--source`: dataset/model name (bentham, iam, rimes, saintgall, washington)
* `--arch`: network to be used (puigcerver, bluche, flor)
* `--transform`: transform dataset to the HDF5 file
* `--cv2`: visualize sample from transformed dataset
* `--kaldi_assets`: save all assets for use with kaldi
* `--image`: predict a single image with the source parameter
* `--train`: train model with the source argument
* `--test`: evaluate and predict model with the source argument
* `--norm_accentuation`: discard accentuation marks in the evaluation
* `--norm_punctuation`: discard punctuation marks in the evaluation
* `--epochs`: number of epochs
* `--batch_size`: number of batches
"""

from __future__ import annotations

import datetime
import os
from collections.abc import Iterator
from pathlib import Path
from typing import cast

from numpy.typing import NDArray

from ..typing import Prediction, Probability
from .data import evaluation, preproc
from .data.generator import DataGenerator, Tokenizer
from .language.model import LanguageModel
from .network.model import HTRModel

# NOTE: For all English alphabet and punctuation
# import string
# CHARSET_BASE = string.printable[:95]
# NOTE: we only require a limited set of characters
CHARSET_BASE = "0123456789n.-+x"
INPUT_SIZE = (1024, 128, 1)
MAX_TEXT_LENGTH = 128

# TODO: reduce repetition by using the dawsonia.ml.api.ML class


def model_predict(
    image: str | Path | NDArray | Iterator[NDArray],
    arch: str = "",
    checkpoint_path: Path | None = None,
    input_size: tuple[int, int, int] = INPUT_SIZE,
    max_text_length: int = MAX_TEXT_LENGTH,
    charset_base: str = CHARSET_BASE,
    tokenizer: Tokenizer | None = None,
    model: HTRModel | None = None,
) -> tuple[Prediction, Probability]:
    """After training, load model and run predictions on an image"""
    # TODO: Important! Get rid of this step and support generator / iterable of images to
    # do batch prediction! Pass generator from function digitize_table_with_model
    if isinstance(image, Iterator):
        raise NotImplementedError("See TODO note above")
    img = preproc.preprocess(image, input_size=input_size)
    x_test = preproc.normalization([img])

    # if isinstance(image, (str, Path)):
    # else:
    #     x_test: NDArray = image

    if not tokenizer:
        if charset_base and max_text_length:
            tokenizer = Tokenizer(chars=charset_base, max_text_length=max_text_length)
        else:
            raise ValueError("Either a Tokenizer or its parameters should be provided.")

    if not model:
        if arch and checkpoint_path:
            model = cast(
                HTRModel,
                make_htr_model(
                    arch,
                    checkpoint_path,
                    vocab_size=tokenizer.vocab_size,
                    input_size=input_size,
                    top_paths=10,
                ),
            )
        else:
            raise ValueError("Either a HTRModel or its parameters should be provided.")

    predicts, probabilities = model.predict(x_test, ctc_decode=True)
    predicts = tuple(tuple(tokenizer.decode(x) for x in y) for y in predicts)
    return predicts, probabilities


def make_datagen(
    predict,
    batch_size,
    source_path,
    max_text_length: int = MAX_TEXT_LENGTH,
    charset_base: str = CHARSET_BASE,
):
    """Data (image) reader"""
    dtgen = DataGenerator(
        source=source_path,
        batch_size=batch_size,
        charset=charset_base,
        max_text_length=max_text_length,
        predict=predict,
    )
    print(f"Train images: {dtgen.size['train']}")
    print(f"Validation images: {dtgen.size['valid']}")
    print(f"Test images: {dtgen.size['test']}")

    return dtgen


def make_htr_model(
    arch,
    checkpoint_path,
    vocab_size,
    input_size=INPUT_SIZE,
    require_checkpoint=True,
    **kwargs,
):
    """Neural network: Handwritten Text Recognition (HTR) system.

    See https://github.com/arthurflor23/handwritten-text-recognition/

    """
    model = HTRModel(
        architecture=arch,
        input_size=input_size,
        beam_width=10,
        vocab_size=vocab_size,
        **kwargs,
    )

    if require_checkpoint and not checkpoint_path.exists():
        raise FileNotFoundError(f"Unable to load model from {checkpoint_path = }")

    model.compile(learning_rate=0.001)
    model.load_checkpoint(target=checkpoint_path)
    return model


def make_kaldi_assets(lang_model_n, output_path, model, dtgen):
    """DataGenerator -> Kaldi language model assets"""
    predicts, _ = model.predict(
        x=dtgen.next_test_batch(), steps=dtgen.steps["test"], ctc_decode=False
    )

    lmodel = LanguageModel(output_path, lang_model_n)
    lmodel.generate_kaldi_assets(dtgen, predicts)


def make_lang_model(
    lang_model_n, norm_accentuation, norm_punctuation, output_path, model, dtgen
):
    """Kaldi language model"""
    lmodel = LanguageModel(output_path, lang_model_n)
    ground_truth = [x.decode() for x in dtgen.dataset["test"]["gt"]]

    start_time = datetime.datetime.now()

    predicts, _ = model.predict(
        x=dtgen.next_test_batch(), steps=dtgen.steps["test"], ctc_decode=False
    )
    lmodel.generate_kaldi_assets(dtgen, predicts)

    lmodel.kaldi(predict=False)
    predicts = lmodel.kaldi(predict=True)
    predicts = [preproc.text_standardize(x) for x in predicts]

    total_time = datetime.datetime.now() - start_time

    with open(
        os.path.join(output_path, "predict_kaldi.txt"), "w", encoding="utf-8"
    ) as fp:
        for pred_value, hdf_ground_truth in zip(predicts, ground_truth):
            fp.write(f"TE_L {hdf_ground_truth}\nTE_P {pred_value}\n")

    evaluate = evaluation.ocr_metrics(
        predicts=predicts,
        ground_truth=ground_truth,
        norm_accentuation=norm_accentuation,
        norm_punctuation=norm_punctuation,
    )

    e_corpus = "\n".join([
        f"Total test images:    {dtgen.size['test']}",
        f"Total time:           {total_time}",
        f"Time per item:        {total_time / dtgen.size['test']}\n",
        "Metrics:",
        f"Character Error Rate: {evaluate[0]:.8f}",
        f"Word Error Rate:      {evaluate[1]:.8f}",
        f"Sequence Error Rate:  {evaluate[2]:.8f}",
    ])

    sufix = (
        ("_norm" if norm_accentuation or norm_punctuation else "")
        + ("_accentuation" if norm_accentuation else "")
        + ("_punctuation" if norm_punctuation else "")
    )

    with open(
        os.path.join(output_path, f"evaluate_kaldi{sufix}.txt"), "w", encoding="utf-8"
    ) as fp:
        fp.write(e_corpus)
        print(e_corpus)


def model_test(norm_accentuation, norm_punctuation, output_path, model, dtgen):
    """Test model after training"""
    start_time = datetime.datetime.now()

    predicts, _ = model.predict(
        x=dtgen.next_test_batch(),
        steps=dtgen.steps["test"],
        ctc_decode=True,
        verbose=1,
    )

    predicts = [dtgen.tokenizer.decode(x[0]) for x in predicts]
    ground_truth = [x.decode() for x in dtgen.dataset["test"]["gt"]]

    total_time = datetime.datetime.now() - start_time

    with open(os.path.join(output_path, "predict.txt"), "w", encoding="utf-8") as fp:
        for pred_value, hdf_ground_truth in zip(predicts, ground_truth):
            fp.write(f"TE_L {hdf_ground_truth}\nTE_P {pred_value}\n")

    evaluate = evaluation.ocr_metrics(
        predicts=predicts,
        ground_truth=ground_truth,
        norm_accentuation=norm_accentuation,
        norm_punctuation=norm_punctuation,
    )

    e_corpus = "\n".join([
        f"Total test images:    {dtgen.size['test']}",
        f"Total time:           {total_time}",
        f"Time per item:        {total_time / dtgen.size['test']}\n",
        "Metrics:",
        f"Character Error Rate: {evaluate[0]:.8f}",
        f"Word Error Rate:      {evaluate[1]:.8f}",
        f"Sequence Error Rate:  {evaluate[2]:.8f}",
    ])

    sufix = (
        ("_norm" if norm_accentuation or norm_punctuation else "")
        + ("_accentuation" if norm_accentuation else "")
        + ("_punctuation" if norm_punctuation else "")
    )

    with open(
        os.path.join(output_path, f"evaluate{sufix}.txt"), "w", encoding="utf-8"
    ) as fp:
        fp.write(e_corpus)
        print(e_corpus)


def model_train(epochs, output_path, checkpoint_path, model, dtgen):
    """Train model"""
    model.summary(output_path, "summary.txt")
    callbacks = model.get_callbacks(
        logdir=output_path, checkpoint=checkpoint_path, verbose=1
    )

    start_time = datetime.datetime.now()

    train_result = model.fit(
        x=dtgen.next_train_batch(),
        epochs=epochs,
        steps_per_epoch=dtgen.steps["train"],
        validation_data=dtgen.next_valid_batch(),
        validation_steps=dtgen.steps["valid"],
        callbacks=callbacks,
        shuffle=True,
        verbose=1,
    )

    total_time = datetime.datetime.now() - start_time

    loss = train_result.history["loss"]
    val_loss = train_result.history["val_loss"]

    min_val_loss = min(val_loss)
    min_val_loss_i = val_loss.index(min_val_loss)

    time_epoch = total_time / len(loss)
    total_item = dtgen.size["train"] + dtgen.size["valid"]

    t_corpus = "\n".join([
        f"Total train images:      {dtgen.size['train']}",
        f"Total validation images: {dtgen.size['valid']}",
        f"Batch:                   {dtgen.batch_size}\n",
        f"Total time:              {total_time}",
        f"Time per epoch:          {time_epoch}",
        f"Time per item:           {time_epoch / total_item}\n",
        f"Total epochs:            {len(loss)}",
        f"Best epoch               {min_val_loss_i + 1}\n",
        f"Training loss:           {loss[min_val_loss_i]:.8f}",
        f"Validation loss:         {min_val_loss:.8f}",
    ])

    with open(os.path.join(output_path, "train.txt"), "w", encoding="utf-8") as fp:
        fp.write(t_corpus)
        print(t_corpus)
