from __future__ import annotations

from pathlib import Path
from dataclasses import dataclass, field

from numpy.typing import NDArray

from .data import preproc
from .ml import make_datagen, make_htr_model, HTRModel, INPUT_SIZE


@dataclass
class ML:
    model_path: Path = Path(
        "/local_disk/", "data", "ai-for-obs", "interim", "model_tmp"
    )
    source: str = "washington"
    arch: str = "flor"
    # raw_path: Path = field(init=False)
    # source_path: Path = field(init=False)
    output_path: Path = field(init=False)
    checkpoint_path: Path = field(init=False)

    model: HTRModel = field(init=False)

    def __post_init__(self):
        model_path = self.model_path = self.model_path.expanduser()
        # self.raw_path = Path(model_path, "raw", source)
        self.source_path = Path(model_path, "data", f"{self.source}.hdf5")
        self.output_path = Path(model_path, "output", self.source, self.arch)
        self.checkpoint_path = Path(self.output_path, "checkpoint_weights.hdf5")

        dtgen = make_datagen(False, 16, self.source_path)
        self.model = make_htr_model(
            self.arch,
            self.checkpoint_path,
            vocab_size=dtgen.tokenizer.vocab_size,
            stop_tolerance=20,
            reduce_tolerance=15,
        )

    def predict(self, image: str | Path | NDArray):
        img = preproc.preprocess(image, input_size=INPUT_SIZE)
        x_test = preproc.normalization([img])

        predicts, probabilities = self.model.predict(x_test, ctc_decode=True)
        return predicts, probabilities
