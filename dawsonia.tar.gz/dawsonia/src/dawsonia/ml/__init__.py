r"""Subpackage ml

This is based on the contents of::

    smhi-computer-vision/
        SMHI_project_handwritten_weather_journals-master/
            Open\ Source\ Neural\ Network/
                src

"""
from .cli import app  # noqa
