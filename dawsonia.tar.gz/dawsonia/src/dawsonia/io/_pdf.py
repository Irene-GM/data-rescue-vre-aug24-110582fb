from __future__ import annotations

import ast
import logging
import random
from pathlib import Path
from typing import Iterator

import numpy as np
from pdf2image import convert_from_path, pdfinfo_from_path

from ..typing import NDArray
from ._book import Book

logger = logging.getLogger(__name__)


def read_pdf_book(
    path_file: Path,
    first_page: int = 1,
    last_page: int = 1_000_000,
    page_middle: int | None = None,
    size_cell: list[float] | None = None,
    table_fmt_dir: Path = Path("table_formats"),
) -> tuple[int, int, Book]:
    """Read PDF book and detect pages"""
    path_file = path_file.expanduser()

    from dawsonia.io import read_specific_table_format

    table_format = read_specific_table_format(table_fmt_dir, path_file)

    logger.info(f"{table_format = }")

    first_page, last_page = check_pdf_page_range(path_file, first_page, last_page)

    book = Book(
        path_file,
        page_middle,
        table_format,
        size_cell or [],
    )

    return first_page, last_page, book


def check_pdf_page_range(path_pdf, first_page=1, last_page=1_000_000, poppler_path=""):
    """Analyze PDF metadata for max. pagenumbers and compare it with input parameters

    Returns
    -------
    first_page, last_page: tuple[int, int]
        The first and last page (with corrections if any or raises a ValueError)

    """

    pdf_info = pdfinfo_from_path(path_pdf, poppler_path=poppler_path)
    logger.info(f"{pdf_info = }")
    max_pages = pdf_info["Pages"]
    if (first_page, last_page) == (0, 0):
        first_page = random.randint(1, max_pages)

    logger.info(f"Setting {first_page = }")
    if last_page > max_pages:
        logger.info("Setting last_page_number = max_pages")
        last_page = max_pages
    elif last_page < first_page:
        logger.info("Setting last_page_number = first_page_number + 1")
        last_page = first_page + 1

    page_range = range(1, max_pages + 1)
    if first_page not in page_range or last_page not in page_range:
        raise ValueError(f"PDF {path_pdf} has only {max_pages} pages.")
    return first_page, last_page


def station_name_from_pdf(path_pdf: Path) -> str:
    """Deduce weather station name from the directory name where it is stored"""
    station = path_pdf.parent.name.lower()
    return station


def year_from_pdf(path_pdf: Path) -> str:
    year = path_pdf.stem.split("_")[-1]
    if not year.isnumeric():
        msg = (
            f"PDF {path_pdf} does not follow the naming convention <station>_<year>.pdf"
        )
        if "-" in year:
            true_year, part_nb = year.split("-")
            if true_year.isnumeric() and part_nb.isnumeric():
                logger.warning(f"{path_pdf=} contains only a part of the year.")
            else:
                raise IOError(msg)
        else:
            raise IOError(msg)

    return year


def get_pdf_pages(
    path_pdf: Path, left_page: int, right_page: int
) -> Iterator[NDArray[np.int16]]:
    """Read two pages from pdf as image"""

    images = convert_from_path(
        path_pdf, poppler_path="", first_page=left_page, last_page=right_page
    )

    # TODO: this overflows at 4096
    # Check if we need np.int32 or np.int64
    for image in images:
        yield np.array(image, dtype=np.int16)


def set_skip_dict(
    skip_table: list[int], skip_rows, skip_cols, table_formats
) -> dict[str, list]:
    """Parse string CLI skip arguments and generate a dictionary of tables, rows
    and columns to skip

    .. todo:: deprecated function!

    """
    if skip_rows:
        rows_to_skip = ast.literal_eval(skip_rows)
    else:
        rows_to_skip = [[]] * len(table_formats)

    if skip_cols:
        cols_to_skip = ast.literal_eval(skip_cols)
    else:
        cols_to_skip = [[]] * len(table_formats)

    skippers = {
        "tables": skip_table,
        "rows": rows_to_skip,
        "cols": cols_to_skip,
    }

    return skippers
