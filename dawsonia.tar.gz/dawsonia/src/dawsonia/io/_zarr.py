from __future__ import annotations

import io
import logging
import random
from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np
import zarr

if TYPE_CHECKING:
    from typing_extensions import TypeAlias
from typing import Iterator

from numcodecs.compat import ensure_bytes
from PIL import Image

from ..typing import NDArray
from ._book import Book

logger = logging.getLogger(__name__)
ZarrArray: "TypeAlias" = zarr.core.Array
ZarrGroup: "TypeAlias" = zarr.hierarchy.Group


def read_zarr_book(
    path_file: Path,
    first_page: int = 1,
    last_page: int = 1_000_000,
    page_middle: int | None = None,
    size_cell: list[float] | None = None,
    table_fmt_dir: Path = Path("table_formats"),
) -> tuple[int, int, Book]:
    """Read zarr book and detect pages"""
    path_file = path_file.expanduser()
    if not path_file.exists():
        raise FileNotFoundError(str(path_file))

    zarr_grp = zarr.open(path_file, mode="r")

    from dawsonia.io import read_specific_table_format

    table_format = read_specific_table_format(table_fmt_dir, zarr_group=zarr_grp)
    logger.info(f"{table_format = }")

    first_page, last_page = check_zarr_page_range(zarr_grp, first_page, last_page)
    return (
        first_page,
        last_page,
        Book(zarr_grp, page_middle, table_format, size_cell or []),
    )


def check_zarr_page_range(
    zarr_grp: ZarrGroup, first_page: int, last_page: int
) -> tuple[int, int]:
    page_range = range(zarr_grp.attrs["first_page"], zarr_grp.attrs["last_page"] + 1)
    max_pages = next(reversed(page_range))

    if (first_page, last_page) == (0, 0):
        first_page = random.randint(1, max_pages)

    logger.info(f"Setting {first_page = }")
    if last_page > max_pages:
        logger.info("Setting last_page_number = max_pages")
        last_page = max_pages
    elif last_page < first_page:
        logger.info("Setting last_page_number = first_page_number + 1")
        last_page = first_page + 1

    if first_page not in page_range or last_page not in page_range:
        raise ValueError(
            f"Zarr has only {max_pages} pages. Asked for {first_page=}, {last_page=}"
        )

    return first_page, last_page


def iter_zarr_pages_ext(
    zarr_grp: ZarrGroup, left_page: int, right_page: int
) -> Iterator[tuple[bytes, str]]:
    left_page_int, right_page_int = check_zarr_page_range(
        zarr_grp, left_page, right_page
    )
    yield from (
        ((page := zarr_grp[f"page_{n}"])["byteimage"][0], page.attrs["ext"])
        for n in range(left_page_int, right_page_int + 1)
    )


def iter_zarr_pages(
    zarr_grp: ZarrGroup, left_page: int, right_page: int
) -> Iterator[bytes]:
    left_page_int, right_page_int = check_zarr_page_range(
        zarr_grp, left_page, right_page
    )
    yield from (
        zarr_grp[f"page_{n}/byteimage"][0]
        for n in range(left_page_int, right_page_int + 1)
    )


def get_zarr_pages_raw(
    zarr_grp: ZarrGroup, left_page: int, right_page: int
) -> Iterator[Image.Image]:
    yield from (
        bytes_to_pil_image(za)
        for za in iter_zarr_pages(zarr_grp, left_page, right_page)
    )


def get_zarr_pages(
    zarr_grp: ZarrGroup, left_page: int, right_page: int
) -> Iterator[NDArray[np.int64]]:
    yield from (
        np.asarray(img) for img in get_zarr_pages_raw(zarr_grp, left_page, right_page)
    )


def station_name_from_zarr(zarr_grp: ZarrGroup):
    return zarr_grp.attrs["station_name"]


def year_from_zarr(zarr_grp):
    return zarr_grp.attrs["year"]


def bytes_to_pil_image(data: bytes) -> Image.Image:
    data = ensure_bytes(data)
    buf = io.BytesIO(data)
    # Initialize a Pillow Image object using the BytesIO object
    image = Image.open(buf)

    # NOTE: alternate method
    # parser = ImageFile.Parser()
    # parser.feed(data)
    # image = parser.close()

    return image
