"""Provides data structures for
- Book: A weather journal book (either .pdf or .ome.zarr)
- Table format: read_specific_table_format

"""

from __future__ import annotations

import datetime
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, cast

if TYPE_CHECKING:
    from typing_extensions import TypeAlias


import numpy as np
import skimage
import zarr
from numpy.typing import NDArray

from ..config import read_table_formats
from ..image_preproc import Preprocessor
from ..typing import (
    MarkArray,
    PreprocConfig,
    PreprocMethods,
    TableFormat,
    TableFormatFile,
    TableFormatFileVersion,
    TableFormatMerged,
    TablePosArrays,
    TableRowIndex,
    TableSizes,
    TimeUnits,
    TransformsConfig,
)
from ..viz import debug_image

logger = logging.getLogger(__name__)
ZarrGroup: "TypeAlias" = zarr.hierarchy.Group


@dataclass
class Book:
    """Encapsulates common parameters specific to a PDF book."""

    file: Path | zarr.hierarchy.Group
    page_middle: int | None
    table_format: TableFormat
    size_cell: list[float]
    preprocessor: Preprocessor = field(default_factory=Preprocessor)

    @property
    def station_name(self):
        from dawsonia.io import get_station_name

        return get_station_name(self.file)

    def read_page(self, page_number: int) -> NDArray:
        from dawsonia.io import get_pages

        array = next(get_pages(self.file, page_number, page_number + 1))

        return array

    def read_image(self, page_number: int) -> NDArray:
        from dawsonia.io import get_pages_raw

        image = next(get_pages_raw(self.file, page_number, page_number + 1))

        return image

    def page_and_tables(
        self, page_number: int
    ) -> tuple[NDArray[np.uint8], TablePosArrays, TableSizes]:
        """Read, preprocess page from book and get positions, sizes of its tables"""
        image = self.read_page(page_number)

        if transforms := self.table_format.transforms:
            image = self.apply_image_transformations(image, transforms)

        debug_image(image, "read_page + apply_image_transformations", gray=False)

        image_preproc, table_positions, table_sizes = self.preprocessor.preprocess(
            self.table_format.tables,
            self.table_format.preproc,
            self.page_middle,
            image,
        )
        table_pos_arrays: TablePosArrays = [
            (
                np.array(table_position).reshape((table_size[0], table_size[1], 4))
                if table_size
                else MarkArray.EMPTY
            )
            for table_position, table_size in zip(table_positions, table_sizes)
        ]

        return image_preproc, table_pos_arrays, table_sizes

    def apply_image_transformations(
        self, image: NDArray[np.int16], transforms: TransformsConfig
    ) -> NDArray[np.int16]:
        dtype = image.dtype
        if angle := transforms.rotate:
            image = skimage.transform.rotate(
                image, angle, resize=True, preserve_range=True
            )

        return image.astype(dtype)

    def crop_image_to_cell(self, image_page, table_pos_array, row, col):
        """Crop image of the page to a table cell specified by row and column index."""
        xp, yp, height, width = table_pos_array[row, col]
        h_by_2 = height / 2
        w_by_2 = width / 2

        # FIXME: move size_cell to preproc
        image_cell = image_page[
            # top:bottom
            int(xp - h_by_2 * self.size_cell[0]) : int(xp + h_by_2 * self.size_cell[1]),
            # left:right
            int(yp - w_by_2 * self.size_cell[2]) : int(yp + w_by_2 * self.size_cell[3]),
        ]

        return image_cell


def read_specific_table_format(
    table_fmt_dir: Path,
    path_file: Path | None = None,
    zarr_group: ZarrGroup | None = None,
) -> TableFormat:
    """Read table_formats.toml file which specifies number of rows and columns
    in all the tables in a page, corresponding to the year.

    """
    from ..io import get_station_name, get_year

    station = get_station_name(path_file or zarr_group)
    year = get_year(path_file or zarr_group)
    if not (station and year):
        raise ValueError(f"Could not read {station=} and {year=}")

    station_tf = (table_fmt_dir / station).with_suffix(".toml")

    try:
        # Copying because we are mutating the table_formats dictionary and it is cached
        import copy

        table_formats: TableFormatFile = copy.deepcopy(read_table_formats(station_tf))
    except FileNotFoundError as err:
        raise ValueError(
            f"Table formats directory should be provided containing a {station}.toml"
            f" file. {table_fmt_dir = }"
        ) from err

    default_version = str(table_formats["default"].pop("version"))
    year_version = str(
        table_formats.get(year, {}).pop(  # type:ignore[attr-defined]
            "version", default_version
        )
    )

    all_versions = cast(dict[str, TableFormatFileVersion], table_formats["version"])
    try:
        version = cast(
            TableFormatMerged,
            (
                # to merge keys like [default.preproc] and [default.transforms]
                table_formats["default"]  # type: ignore[operator]
                # to merge keys like [1942.preproc] and [1942.transforms]
                | table_formats.get(year, {})  # type: ignore[operator]
                | all_versions[default_version]  # type: ignore[operator]
                | all_versions[year_version]  # type: ignore[operator]
            ),
        )
    except KeyError as err:
        raise ValueError(
            f"Version ({ {year_version, default_version} - all_versions.keys() }) "
            "missing from table formats TOML file: "
        ) from err

    preproc = version.get("preproc", {})
    if isinstance((row_idx_unit := preproc.get("row_idx_unit")), str):
        preproc["row_idx_unit"] = TimeUnits[row_idx_unit]

    if isinstance((method := preproc.get("method")), str):
        preproc["method"] = PreprocMethods[method]

    preproc_config = PreprocConfig(**preproc)  # type:ignore[arg-type]

    if transforms := version.get("transforms"):
        transforms_config = TransformsConfig(**transforms)
    else:
        transforms_config = None

    if preproc_config.row_idx_unit == TimeUnits.HOURS:
        row_idx: TableRowIndex = tuple(
            idx if isinstance(idx, datetime.time) else datetime.time(cast(int, idx), 0)
            for idx in version["rows"]
        )
    elif preproc_config.row_idx_unit == TimeUnits.DAYS:
        row_idx = tuple(
            datetime.timedelta(days=cast(int, idx)) for idx in version["rows"]
        )
    else:
        row_idx = version["rows"]

    tf = TableFormat(
        version["name_idx"],
        version["columns"],
        row_idx,
        version["tables"],
        preproc_config,
        transforms_config,
        year_version,
        station,
    )
    return tf
