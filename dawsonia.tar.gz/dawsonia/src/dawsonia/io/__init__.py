from __future__ import annotations

import os
from pathlib import Path
from typing import Iterator

import zarr
from numpy.typing import NDArray
from PIL.Image import Image

from ._book import Book, read_specific_table_format
from ._pdf import (
    check_pdf_page_range,
    get_pdf_pages,
    read_pdf_book,
    station_name_from_pdf,
    year_from_pdf,
)
from ._zarr import (
    ZarrGroup,
    get_zarr_pages,
    get_zarr_pages_raw,
    read_zarr_book,
    station_name_from_zarr,
    year_from_zarr,
)

__all__ = (
    "get_pages",
    "get_station_name",
    "get_year",
    "read_book",
    "Book",
    "read_specific_table_format",
    "check_pdf_page_range",
)


def _as_zarr_group(path_or_zarr: Path | ZarrGroup) -> ZarrGroup:
    if isinstance(path_or_zarr, Path):
        return zarr.open(path_or_zarr, mode="r")
    else:
        return path_or_zarr


def all_books(top_dir, ext=".zarr.zip") -> Iterator[Path]:
    yield from (
        Path(root) / file
        for root, _, files in os.walk(top_dir)
        for file in files
        if file.endswith(ext) and "img" not in file
    )


def read_book(
    path_file: str | Path,
    first_page: int = 1,
    last_page: int = 1_000_000,
    page_middle: int | None = None,
    size_cell: list[float] | None = None,
    table_fmt_dir: str | Path = Path("table_formats"),
) -> tuple[int, int, Book]:
    """Read Book"""
    file = Path(path_file)
    table_fmt_path = Path(table_fmt_dir)

    if not table_fmt_path.exists():
        raise LookupError(f"Expected a directory {table_fmt_path}")

    if file.suffix == ".pdf":
        reader = read_pdf_book
    else:
        reader = read_zarr_book

    return reader(file, first_page, last_page, page_middle, size_cell, table_fmt_path)


def get_pages(
    file: Path | ZarrGroup, left_page: int, right_page: int
) -> Iterator[NDArray]:
    if isinstance(file, Path) and file.suffix == ".pdf":
        return get_pdf_pages(file, left_page, right_page)
    else:
        return get_zarr_pages(_as_zarr_group(file), left_page, right_page)


def get_pages_raw(
    file: Path | ZarrGroup, left_page: int, right_page: int
) -> Iterator[Image]:
    if isinstance(file, Path) and file.suffix == ".pdf":
        raise NotImplementedError("This is not implemeneted for PDFs")
    else:
        return get_zarr_pages_raw(_as_zarr_group(file), left_page, right_page)


def get_station_name(file: Path | ZarrGroup):
    if isinstance(file, Path) and file.suffix == ".pdf":
        return station_name_from_pdf(file)
    else:
        return station_name_from_zarr(_as_zarr_group(file))


def get_year(file: Path | ZarrGroup):
    if isinstance(file, Path) and file.suffix == ".pdf":
        return year_from_pdf(file)
    else:
        return year_from_zarr(_as_zarr_group(file))
