def encode(book: int, page: int, row: int, col: int, table: int) -> str:
    count = format(book, "b")
    leading_zeros = "0" * (16 - len(count))
    key1 = leading_zeros + count
    count = format(page, "b")
    leading_zeros = "0" * (10 - len(count))
    key2 = leading_zeros + count
    count = format(row, "b")
    leading_zeros = "0" * (4 - len(count))
    key3 = leading_zeros + count
    count = format(col, "b")
    leading_zeros = "0" * (4 - len(count))
    key4 = leading_zeros + count
    count = format(table, "b")
    key5 = count
    key_name = key1 + key2 + key3 + key4 + key5
    key_name = str(int(key_name, 2))
    key_name = key_name
    return key_name


def decode(key: int, printer: bool = True) -> tuple[int, ...]:
    key_binary = format(key, "b")
    length = 16 + 10 + 4 + 4 + 1
    b = "0" * (length - len(key_binary)) + key_binary
    book = b[0:16]
    page = b[16:26]
    row = b[26:30]
    col = b[30:34]
    table = b[34:35]

    def as_binary_int(string) -> int:
        return int(string, base=2)

    if printer:
        print(f"Book = {book}, Page = {page}, row,col = {row,col},table = {table}")

    return tuple(as_binary_int(string) for string in (book, page, row, col, table))
