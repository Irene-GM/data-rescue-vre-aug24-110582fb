"""Labelling CLI and GUI"""

# NOTE: we disable this here because default options can be represented using typing.Annotated
# from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Annotated

import imageio
import numpy as np
import typer

if TYPE_CHECKING:
    import tkinter

from .config import config_cli_names, config_kwargs
from .image_id import encode
from .io import Book, read_book
from .typing import MarkArray, NDArray

logger = logging.getLogger(__name__)
app = typer.Typer()


@app.callback(invoke_without_command=True)
def command(
    path_file: Path,
    first_page: Annotated[int, typer.Option("-f", "--first-page")] = 0,
    last_page: Annotated[int, typer.Option("-l", "--last-page")] = 0,
    page_middle: Annotated[
        int,
        typer.Option(
            "-m",
            "--page-middle",
            help="X coordinate of middle of page to help the rotation correction",
        ),
    ] = None,
    size_cell: tuple[float, float, float, float] = [
        1,
        1,
        1,
        1,
    ],  # left, right, bottom, top
    interactive: bool = True,
    table_fmt_dir: Path = Path("table_formats"),
    output_path: Path = Path("output", "label"),
    config: Path = typer.Option("dawsonia.toml", *config_cli_names, **config_kwargs),
):  # pylint: disable=unused-argument, too-many-arguments, too-many-locals
    """Label PDF images to create raw training data."""
    # NOTE: if ctx: typer.Context is one of the arguments
    # logger.info(f"dawsonia label {ctx.params = }")

    first_page, last_page, book = read_book(
        path_file,
        first_page,
        last_page,
        page_middle,
        # skip_table,
        # skip_rows,
        # skip_cols,
        list(size_cell),
        table_fmt_dir,
    )

    output_path.mkdir(exist_ok=True, parents=True)

    for page_number in range(first_page, last_page + 1):
        label_page(
            book,
            page_number,
            output_path,
            interactive,
        )


def labelling_gui(output_path: Path, key_name):
    """GUI for manually entering labels to detected table cells."""
    import tkinter  # pylint: disable=import-outside-toplevel

    root = tkinter.Tk()
    root.geometry("300x300+0+0")  # position and size of the windows
    canvas = tkinter.Canvas(root, width=300, height=300)
    canvas.pack()
    img = tkinter.PhotoImage(
        file=(output_path / "temp.png")
    )  # open the temporary image
    canvas.create_image(20, 20, anchor="nw", image=img)  # show the image
    entry1 = tkinter.Entry(root)  # get input
    canvas.create_window(100, 200, window=entry1)  # position of the input button
    button1 = tkinter.Button(
        text="put value",
        command=lambda: save_labelled_image(entry1, key_name, root, output_path),
    )  # call save_data
    canvas.create_window(100, 250, window=button1)  # position of the button "put_value"

    tkinter.mainloop()


def save_labelled_image(
    entry1: "tkinter.Entry", key_name: str, root: "tkinter.Tk", output_path: Path
):
    """Save input label as the filename of image."""
    label = entry1.get()  # get the input (so the value of the case)
    name = key_name + str(label) + ".png"
    pattern = key_name + "*" + ".png"
    for file in output_path.glob(pattern):
        file.unlink()
    (output_path / "temp.png").rename(output_path / name)
    root.destroy()  # destroy the windows


def label_page(
    book: Book,
    page_number: int,
    output_path: Path,
    interactive: bool,
):
    """Convert chosen page to image, label the detected cells and save it in
    ``output_path``.
    """
    image_preproc, table_positions, table_sizes = book.page_and_tables(page_number)
    for table_nb, table_size in enumerate(table_sizes):
        table_pos_array = table_positions[table_nb]
        if table_pos_array is MarkArray.EMPTY:
            logger.info(f"Table {table_nb} not detected")
            continue

        label_table(
            book,
            image_preproc,
            output_path,
            interactive,
            page_number,
            table_nb,
            table_size,
            table_pos_array,
        )


def label_table(
    book: Book,
    image_page: NDArray,
    output_path: Path,
    interactive: bool,
    page_number: int,
    table_nb: int,
    table_size: list,
    table_pos_array: NDArray,
):
    """Crop image to extract table cells based on its positions and
    (non-)interactively save images.
    """
    book_number = 0
    for row in range(table_size[0]):
        for col in range(table_size[1]):
            image_cell = book.crop_image_to_cell(image_page, table_pos_array, row, col)
            key_name = encode(book_number, page_number, row, col, table_nb) + "_"

            if not interactive:  # if we are not labelling the image
                image_path = output_path / (key_name + "nolabel" + ".png")

                if not image_path.exists():
                    imageio.imwrite(
                        image_path, image_cell.astype(np.uint8)
                    )  # Save image and continue
            else:
                imageio.imwrite(
                    output_path / "temp.png",
                    image_cell.astype(np.uint8),
                )  # save the image in a temporary file
                labelling_gui(output_path, key_name)
