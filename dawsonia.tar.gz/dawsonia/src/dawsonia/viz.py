from __future__ import annotations

import logging
import os
from functools import partial
from typing import Sequence

import matplotlib.pyplot as plt
import numpy as np
from matplotlib import patches
from matplotlib.collections import PatchCollection
from matplotlib.patches import Rectangle
from numpy import median
from numpy.typing import NDArray
from skimage import filters

from dawsonia.typing import BBoxTuple, ClusterLabel

histplot: Callable | partial
try:
    from collections.abc import Callable

    import seaborn as sns

    histplot = partial(sns.histplot, kde=True)
except ImportError:

    def histplot(data, *, ax: plt.Axes, bins):
        ax.hist(data, bins=bins)
        return ax


DAWSONIA_DEBUG = os.getenv("DAWSONIA_DEBUG")
DAWSONIA_DEBUG_TABLE_DETECT = os.getenv("DAWSONIA_DEBUG_TABLE_DETECT")
logger = logging.getLogger(__name__)


def debug_image(im: NDArray, title: str = "", gray=True):
    if not DAWSONIA_DEBUG:
        return

    cmap = plt.cm.gray if gray else None  # type: ignore[attr-defined]

    plt.figure()
    plt.imshow(im, cmap=cmap)
    plt.suptitle(title)
    stats = f"{im.min()=} {im.max()=} {median(im)=} {im.dtype=}"
    plt.title(stats)
    logger.debug(f"debug_image: {stats:70} [{title}]")
    plt.show()


def debug_threshold(image: NDArray, title: str = "debug_threshold"):
    if not DAWSONIA_DEBUG:
        return

    fig, ax = filters.try_all_threshold(image, figsize=(10, 8), verbose=False)
    fig.suptitle(f"debug_threshold: {title}")
    plt.show()


def debug_tables_detected(
    image: NDArray, label_image: NDArray[np.int64], min_area: int
):
    if not DAWSONIA_DEBUG and not DAWSONIA_DEBUG_TABLE_DETECT:
        return

    import matplotlib.patches as mpatches
    from skimage.color import label2rgb
    from skimage.measure import regionprops

    image_label_overlay = label2rgb(label_image, image=image)

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.set(title="debug_tables_detected")
    ax.imshow(image_label_overlay)

    for region in regionprops(label_image):
        # take regions with large enough areas
        if region.area >= min_area:
            # draw rectangle around segmented coins
            minr, minc, maxr, maxc = region.bbox
            rect = mpatches.Rectangle(
                (minc, minr),
                maxc - minc,
                maxr - minr,
                fill=False,
                edgecolor="red",
                linewidth=2,
            )
            ax.add_patch(rect)

    plt.show()


def debug_table_positions(
    image_filter, pos_list, size_list, label_tables=None, printer=False
):
    """plot image for debug
    Parameters
    ----------
    image_filter : array 2D
        grey image of a page without background noise
    pos_list : list
        Each element of this list is a list containing the informations of each
        box of a table. The format of the information is::

           [
                vertical position [int],
                horizontal position [int],
                width [int],
                height [int]
           ]

        the position is defined in relation to the position on the whole page
        and not in relation to the relative position of the table
    size_list : list
        list of the size of tables
    """
    if not DAWSONIA_DEBUG and not DAWSONIA_DEBUG_TABLE_DETECT:
        return

    fig = plt.figure(layout="constrained", figsize=(12, 8))
    fig.suptitle("debug_table_positions")
    if label_tables is None:
        ax = fig.subplots()
    else:
        binary = label_tables.copy()
        binary[label_tables > 0] = 1

        proj = {}
        proj["x"] = binary.sum(axis=0)
        proj["y"] = binary.sum(axis=1)

        inner_x = [["xi"], ["xh"]]
        inner_y = [["yi", "yh"]]
        axd = fig.subplot_mosaic(
            [["image", inner_y], [inner_x, "BLANK"]], empty_sentinel="BLANK"
        )

        ax = axd["image"]

        xs = np.arange(binary.shape[1])
        ys = np.arange(binary.shape[0])

        axd["xi"].plot(xs, proj["x"])
        axd["yi"].plot(proj["y"], ys)
        axd["xi"].sharex(ax)
        axd["yi"].sharey(ax)
        axd["xi"].set(
            title=f"{proj['x'].max()=} {median(proj['x'])=}",
            xlabel="x (pixels)",
            ylabel="proj_x accumulated",
        )
        axd["yi"].set(
            title=f"{proj['y'].max()=} {median(proj['y'])=}",
            ylabel="y (pixels)",
            xlabel="proj_y accumulated",
        )

        histplot(proj["x"], ax=axd["xh"], bins=100)
        histplot(proj["y"], ax=axd["yh"], bins=100)
        axd["xh"].set(title="histogram", xlabel="proj_x", ylabel="n")
        axd["yh"].set(title="histogram", xlabel="proj_y", ylabel="n")

    ax.imshow(image_filter, cmap=plt.cm.gray)
    ax.set_title("image_filter")

    # FIXME: use nb_tables_verify_size for i_table
    for i_table, table_pos in enumerate(pos_list):
        if not size_list[i_table]:
            continue

        for k in range(size_list[i_table][0] * size_list[i_table][1]):
            if printer:
                print("Size: ", size_list)
                print("positions length: ", len(pos_list))

                print("num_fig: ", i_table)
                print("k: ", k)
                print("positions[numfig] length: ", len(pos_list[i_table]))

            position = table_pos[k]

            rect = patches.Rectangle(
                xy=(  # bottom-left coordinates calculated from center
                    position[1] - position[3] // 2,
                    position[0] - position[2] // 2,
                ),
                width=position[3],
                height=position[2],
                edgecolor="r",
                facecolor="none",
            )
            ax.add_patch(rect)

    plt.show()


def make_patch_collection_from_bboxes(
    bboxes, facecolor: str | NDArray[np.float64] = "r"
) -> PatchCollection:
    rects = [Rectangle((x, y), xl, yl) for x, y, xl, yl in bboxes]
    # Loop over data points; create box from errors at each point

    # Create patch collection with specified colour/alpha
    pc = PatchCollection(
        rects, facecolor=facecolor, alpha=0.2, edgecolor="k", linewidths=2
    )

    return pc


def debug_image_table_detect_opencv_contours(
    filtered_image, thresh_value, dilated_value, original_image, bboxes
):
    import matplotlib.pyplot as plt

    from dawsonia.viz import DAWSONIA_DEBUG, DAWSONIA_DEBUG_TABLE_DETECT

    if not DAWSONIA_DEBUG and not DAWSONIA_DEBUG_TABLE_DETECT:
        return

    pc = make_patch_collection_from_bboxes(bboxes)
    ratio, lims = _get_bbox_extent(bboxes)

    axd = plt.figure(
        figsize=(figwidth := 12 if ratio < 1 else 8, ratio * figwidth),
        layout="constrained",
    ).subplot_mosaic(
        """
        AB
        CD
"""
    )
    axd["A"].imshow(filtered_image, cmap="gray")
    axd["A"].set_title("filtered")
    axd["B"].imshow(thresh_value, cmap="gray_r")
    axd["B"].set_title("thresh (inverted colours)")
    axd["C"].imshow(dilated_value, cmap="gray_r")
    axd["C"].set_title("dilated (inverted colours)")
    axd["D"].imshow(original_image, cmap="gray")
    axd["D"].set_title("original + detected images")

    # Add patch collection to axes
    axd["C"].add_collection(pc)

    for ax in axd.values():
        ax.set(xlim=(lims[0].start, lims[0].stop), ylim=(lims[1].stop, lims[1].start))

    plt.title(f"table_detect_opencv_contours: {len(bboxes)} contours")
    plt.show()


def _get_bbox_extent(
    bboxes: Sequence[BBoxTuple],
    # ) -> tuple[tuple[float, float, float, float], tuple[slice, slice]]:
) -> tuple[float, tuple[slice, slice]]:
    bbox_arr = np.array(bboxes, dtype="int64")
    xmin = bbox_arr[:, 0].min()
    xmax = bbox_arr[:, 0].max() + bbox_arr[:, 2].max()
    ymin = bbox_arr[:, 1].min()
    ymax = bbox_arr[:, 1].max() + bbox_arr[:, 3].max()
    # extent = (xmin, xmax, ymax, ymin)
    ratio = (ymax - ymin) / (xmax - xmin)
    lims = slice(xmin - 10, xmax + 10), slice(ymin - 10, ymax + 10)
    return ratio, lims


def debug_clustered_bboxes(
    ref_image: NDArray,
    bboxes: Sequence[BBoxTuple],
    sorted_cluster_bboxes: dict[ClusterLabel, Sequence[BBoxTuple]],
) -> None:
    patches: list[PatchCollection] = []
    for cluster_bbox_idxs in sorted_cluster_bboxes.values():
        # generate a random color for the cluster
        color = np.random.random(3)

        # loop over the sorted indexes
        patches.append(
            make_patch_collection_from_bboxes(
                [bboxes[i] for i in cluster_bbox_idxs], color
            )
        )

    fig, ax = plt.subplots(figsize=(18, 12))
    ax.imshow(ref_image, cmap="gray_r")
    ax.set_title("reference image (inverted colours) and clusted bboxes")
    for pc in patches:
        ax.add_collection(pc)
    plt.show()
