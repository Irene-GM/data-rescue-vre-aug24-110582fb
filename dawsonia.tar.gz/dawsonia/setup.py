"""This bare-bones setup script exists to allow for ``pip install -e .`` invocation.
All metadata should be preferably entered in ``setup.cfg``.

"""
import sys
from setuptools import setup


NAME = "dawsonia"

if "bdist_rpm" in sys.argv:
    NAME = f"python3-{NAME}"


setup(
    name=NAME,
)
