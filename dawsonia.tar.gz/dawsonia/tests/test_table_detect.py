from __future__ import annotations

from pathlib import Path

import pytest
from dawsonia.io import read_specific_table_format
from dawsonia.typing import TableFormat


@pytest.mark.parametrize("year", ["1938-0", "1938-1", *range(1925, 1949)])
@pytest.mark.parametrize(
    "station",
    [
        "BJURÖKLUBB",
        "HAPARANDA",
        "HÄRNÖSAND",
        "HOBURG",
        "HOLMÖGADD",
        "LANDSORT",
        "KALMAR",
        "MALMSLÄTT",
        "ÖLAND",
        "VÄDERÖBOD",
        "VINGA",
        "VISBY",
    ],
)
def test_table_format(year: int | str, station: str):
    table_fmt_dir = Path(__file__).parent.parent / "table_formats"
    fake_pdf = Path(f"/path/to/{station}/DAGBOK_{station.title()}_Station_{year}.pdf")
    table_fmt = read_specific_table_format(table_fmt_dir, fake_pdf)
    assert isinstance(table_fmt, TableFormat)
    table0 = table_fmt.tables[0]
    table1 = table_fmt.tables[1]
    # check number of rows match the table's rows
    assert len(table_fmt.rows) == table0[0] == table1[0]
    # check number of cols match the table's cols
    assert len(table_fmt.columns[0]) == table0[1]
    assert len(table_fmt.columns[1]) == table1[1]

    all_columns = table_fmt.columns[0] + table_fmt.columns[1]
    repeating_columns = [*all_columns]
    for column in (unique_columns := set(all_columns)):
        repeating_columns.remove(column)
    assert len(unique_columns) == table0[1] + table1[1], f"{repeating_columns=}"
