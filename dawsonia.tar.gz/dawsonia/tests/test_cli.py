import shlex
import sys
import pytest
from unittest.mock import patch

from dawsonia.cli import app


@pytest.mark.parametrize(
    "argv", [f"dawsonia {cmd}" for cmd in ("", "label", "prepare", "ml", "digitize")]
)
def test_cli_help(argv: str):
    with patch.object(sys, "argv", shlex.split(argv) + ["-h"]):
        with pytest.raises(SystemExit):
            app()
