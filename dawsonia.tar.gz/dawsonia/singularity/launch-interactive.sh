#!/bin/bash

set -euo pipefail

rm -rf run.sh
cat > run.sh << EOF
#!/bin/bash -e
cd /myrun
\$WITH_CONDA

export PYTHONPATH=/build/venv/lib/python3.10/site-packages
export PATH="\$PATH:/build/venv/bin"
EOF


PROJECT_DIR="$PROJECT/dawsonia"
SCRATCH_DIR="$SCRATCH/data"
BUILD_DIR="$SCRATCH/build"

sif=$(realpath $SCRATCH/sifs/lumi-tensorflow-rocm-5.5.1-python-3.10-tensorflow-2.11.1-horovod-0.28.1-v2.sif)

print_help() {
    echo "$0: launch an interactive shell using Singularity in the login node (default) or a compute node."
    echo "  Usage:"
    echo "    $0 [-hsg]"
    echo "  Options:"
    echo "    -h      show this menu"
    echo "    -s      launch into a compute node using SLURM (debug partition)"
    echo "    -g      allocate a GPU while launching into a compute node (dev-g partition)"
}

update=0
use_conda=0

OPTIND=1 # Reset in case getopts has been used previously in the shell

use_slurm=0
use_gpu=0

OPTIND=1 # Reset in case getopts has been used previously in the shell
while getopts "hsg" opt; do
    case "$opt" in
    h)
        print_help
        exit 0
        ;;
    s)
        use_slurm=1
        ;;
    g)
        use_slurm=1
        use_gpu=1
        ;;
    esac
done

shift $((OPTIND-1))

if [ $use_gpu -eq 1 ]; then
    RESOURCES="--partition=dev-g --ntasks=8 --gpus=1"
else
    RESOURCES="--partition=debug --ntasks=4"
fi

if [ $use_slurm -eq 1 ]; then
    SCMD="srun  --interactive --pty --account=project_465000677 $RESOURCES --time=3:00:00"
else
    SCMD=""
fi

export SCMD="$SCMD \
    singularity exec \
        -B $PROJECT_DIR:/project \
        -B $SCRATCH_DIR:/scratch \
        -B $BUILD_DIR:/build \
        -B $(pwd):/myrun
        -B /var/spool/slurmd     -B /opt/cray     -B /usr/lib64/libcxi.so.1     -B /usr/lib64/libjansson.so.4\
        $sif \
        bash --rcfile /myrun/run.sh"

$SCMD
