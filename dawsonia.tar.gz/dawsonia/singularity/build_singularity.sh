#!/bin/bash -ie
# NOTE: build using
# ❌ apptainer version 1.2.4-1.el8
# ✅ singularity-ce version 3.11.5-1.el9

export SINGULARITY_TMPDIR="$PWD/.tmp"
rm -rf "$SINGULARITY_TMPDIR"
mkdir "$SINGULARITY_TMPDIR"

BASE=./lumi-tensorflow-rocm-5.5.1-python-3.10-tensorflow-2.11.1-horovod-0.28.1-v0.sif
# BASE=./docker/lumi-tensorflow-rocm-5.5.1-python-3.10-tensorflow-2.11.1-horovod-0.28.1.tar
CUSTOM="${BASE/v0/v2}"

## Using cotainr
## FIXME: unusable! goes out-of-memory
# cotainr build \
#     -v --log-to-file \
#     --conda-env environment_cotainr.yaml \
#     --base-image $BASE \
#     lumi-tensorflow-rocm-cotainr.sif


##  Interactive
# singularity build --sandbox lumi-tensorflow-rocm-sandbox $BASE
# singularity shell --writable lumi-tensorflow-rocm-sandbox

# FIXME: did not work, requires --fakeroot
# singularity build --update --sandbox --fix-perms lumi-tensorflow-rocm-sandbox build_singularity.def

singularity build -B "$PWD/envs":/tmp/envs --fakeroot --fix-perms $CUSTOM build_singularity.def
