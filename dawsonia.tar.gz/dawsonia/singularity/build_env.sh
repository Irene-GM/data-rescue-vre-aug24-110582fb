#!/bin/bash -e


PROJECT_DIR="$PROJECT/dawsonia"
SCRATCH_DIR="$SCRATCH/data"
BUILD_DIR="$SCRATCH/build"
EXTRA_PACKAGES="optuna"

SCRIPT="$PWD/.singularity_install.sh"


# --- end of parameters ---

print_help() {
    echo "$0: install necessary packages and project into $BUILD_DIR"
    echo "  Usage:"
    echo "    $0 [-huv]"
    echo "  Options:"
    echo "    -h      show this menu"
    echo "    -u      update and not remove existing built venv"
    echo "    -c      build into a conda env instead of venv (default)"
    echo " NOTE: create a ~/.condarc file with the following so that your home directory will not fill up:

envs_dirs:
  - /build/conda/envs

"
}

update=0
use_conda=0

OPTIND=1 # Reset in case getopts has been used previously in the shell
while getopts "h?uc" opt; do
    case "$opt" in
    h|\?)
        print_help
        exit 0
        ;;
    u)
        # Update the pypi package cache
        update=1
        ;;
    c)
        use_conda=1
        ;;
    esac
done

shift $((OPTIND-1))

[ "${1:-}" = "--" ] && shift

if [ $use_conda -eq 0 ]; then
    CMD_ACTIVATE="source /build/venv/bin/activate"
    CMD_INSTALL="python -m pip install $EXTRA_PACKAGES --editable '.[pypi]'"
    CMD_FREEZE_REQUIREMENTS="pip freeze | sed 's/^-e.*egg=.*/-e\ \.\./g' > /project/singularity/envs/environment_and_venv.txt"
else
    CMD_ACTIVATE="conda activate myconda"
    CMD_INSTALL="conda install pillow && python -m pip install $EXTRA_PACKAGES --editable '.'"
    CMD_FREEZE_REQUIREMENTS="conda env export > /project/singularity/envs/environment_cloned.yaml"
fi

if [ $update -eq 1 ] && [ -d "$BUILD_DIR/venv" ] ; then
    CMD_MKVENV=""
else
    if [ $use_conda -eq 0 ]; then
        CMD_MKENV="python -m venv --system-site-packages /build/venv"
    else
        CMD_MKENV="conda create --clone tensorflow -n myenv"
    fi
    rm -rf $BUILD_DIR
    mkdir $BUILD_DIR
fi

cat > $SCRIPT <<EOF
\$WITH_CONDA
set -xe
which python
conda env export > /project/singularity/envs/environment_only.yaml

$CMD_MKENV
$CMD_ACTIVATE

pushd /project
$CMD_INSTALL
$CMD_FREEZE_REQUIREMENTS
EOF
chmod +x $SCRIPT

singularity exec \
    -B $PROJECT_DIR:/project \
    -B $SCRATCH_DIR:/scratch \
    -B $BUILD_DIR:/build \
    ./sifs/lumi-tensorflow-rocm-5.5.1-python-3.10-tensorflow-2.11.1-horovod-0.28.1-v2.sif /project/singularity/.singularity_install.sh
rm "$SCRIPT"
