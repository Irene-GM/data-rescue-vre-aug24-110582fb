#!/bin/bash -e
#SBATCH -J launch-test-slurm
#SBATCH -A project_465000677
#SBATCH -p ju-standard-g
#SBATCH --threads-per-core 1
#SBATCH --exclusive
#SBATCH -N 4
#SBATCH --gpus 32
#SBATCH -t 2:00:00
#SBATCH --mem 0
#SBATCH -o test.out
#SBATCH -e test.err

set -o pipefail
export NCCL_SOCKET_IFNAME=hsn0,hsn1,hsn2,hsn3

#
# Execute examples
#

c=fe
#
# Bind mask for one and  thread per core
#
MYMASKS1="0x${c}000000000000,0x${c}00000000000000,0x${c}0000,0x${c}000000,0x${c},0x${c}00,0x${c}00000000,0x${c}0000000000"
MYMASKS2="0x${c}00000000000000${c}000000000000,0x${c}00000000000000${c}00000000000000,0x${c}00000000000000${c}0000,0x${c}00000000000000${c}000000,0x${c}00000000000000${c},0x${c}00000000000000${c}00,0x${c}00000000000000${c}00000000,0x${c}00000000000000${c}0000000000"

export SCMD="srun   -N 4   -n 32   --cpu-bind=mask_cpu:$MYMASKS1   --gpus 32   singularity exec     -B /var/spool/slurmd     -B /opt/cray     -B /usr/lib64/libcxi.so.1     -B /usr/lib64/libjansson.so.4"


    wrapper=$(realpath wrapper-test-rocm-5.5.1-python-3.10-tensorflow-2.11.1-horovod-0.28.1.sh)
    # sif=$(realpath /appl/local/containers/sif-images/lumi-tensorflow-rocm-5.5.1-python-3.10-tensorflow-2.11.1-horovod-0.28.1.sif)
    sif=$(realpath $SCRATCH/sifs/lumi-tensorflow-rocm-5.5.1-python-3.10-tensorflow-2.11.1-horovod-0.28.1-v2.sif)

    $wrapper $sif |& tee test.log
