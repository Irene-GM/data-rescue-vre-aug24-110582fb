#!/bin/bash -ex
set -o pipefail

# NOTE: if a conda environment was build instead of setting PYTHONPATH and PATH, use:
# conda activate myenv

rm -rf run.sh
cat > run.sh << EOF
#!/bin/bash -e
cd /myrun
\$WITH_CONDA

export PYTHONPATH=/build/venv/lib/python3.10/site-packages
export PATH="\$PATH:/build/venv/bin"

set -x
  command -v python
  python -m site

  # Download on single rank
  # if [ \$SLURM_PROCID -eq 0 ] ; then
  #   python mnist-download.py
  # fi
  # exit 0

  export NCCL_SOCKET_IFNAME=hsn0,hsn1,hsn2,hsn3
  export MIOPEN_USER_DB_PATH="/tmp/$(whoami)-miopen-cache-\$SLURM_NODEID"
  export MIOPEN_CUSTOM_CACHE_DIR=\$MIOPEN_USER_DB_PATH

  # Set MIOpen cache out of the home folder.
  if [ \$SLURM_LOCALID -eq 0 ] ; then
    rm -rf \$MIOPEN_USER_DB_PATH
    mkdir -p \$MIOPEN_USER_DB_PATH
  fi
  sleep 3

  # Report affinity
  echo "Rank \$SLURM_PROCID --> \$(taskset -p \$\$)"

  rocm-smi

  cd /project
  # dawsonia ml ....
  # dawsonia digitize ...
  # python scripts/digitize_distributed.py
  python /myrun/ml-data-prepare-transform.py $2
EOF
chmod +x run.sh

$SCMD \
    -B $(pwd):/myrun \
    $1 \
    /myrun/run.sh
