#!/bin/bash -e
#SBATCH -J flor
#SBATCH -A project_465000677
#SBATCH --threads-per-core 1
#SBATCH --ntasks 8
#SBATCH --gpus 1
#SBATCH -t 2-00:00:00
#SBATCH -p small-g
#SBATCH --mem 0
#SBATCH -o slurm-%J-venv.out
#SBATCH -e slurm-%J-venv.err
##NOSBATCH -N 1
##NOSBATCH --gpus 8
##NOSBATCH -p ju-standard-g
##NOSBATCH --exclusive

set -o pipefail
export NCCL_SOCKET_IFNAME=hsn0,hsn1,hsn2,hsn3

#
# Execute examples
#

c=fe
#
# Bind mask for one and  thread per core
#
MYMASKS1="0x${c}000000000000,0x${c}00000000000000,0x${c}0000,0x${c}000000,0x${c},0x${c}00,0x${c}00000000,0x${c}0000000000"
MYMASKS2="0x${c}00000000000000${c}000000000000,0x${c}00000000000000${c}00000000000000,0x${c}00000000000000${c}0000,0x${c}00000000000000${c}000000,0x${c}00000000000000${c},0x${c}00000000000000${c}00,0x${c}00000000000000${c}00000000,0x${c}00000000000000${c}0000000000"

PROJECT_DIR="$PROJECT/dawsonia"
SCRATCH_DIR="$SCRATCH/data"
BUILD_DIR="$SCRATCH/build"

# export SCMD="srun  -N 1  -n 8  --cpu-bind=mask_cpu:$MYMASKS1  --gpus 8  \
export SCMD="srun -n 1 --gpus 1  \
    singularity exec \
        -B $PROJECT_DIR:/project \
        -B $SCRATCH_DIR:/scratch \
        -B $BUILD_DIR:/build \
        -B /var/spool/slurmd     -B /opt/cray     -B /usr/lib64/libcxi.so.1     -B /usr/lib64/libjansson.so.4"


    wrapper=$(realpath wrapper-venv-rocm-5.5.1-python-3.10-tensorflow-2.11.1-horovod-0.28.1.sh)
    sif=$(realpath $SCRATCH/sifs/lumi-tensorflow-rocm-5.5.1-python-3.10-tensorflow-2.11.1-horovod-0.28.1-v2.sif)

    $wrapper "$sif" $SLURM_JOB_NAME |& tee slurm-${SLURM_JOBID}-venv.log
