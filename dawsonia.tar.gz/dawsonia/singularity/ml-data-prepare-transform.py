#!/usr/bin/env python
import subprocess
import sys
from itertools import chain, zip_longest
from pathlib import Path

import numpy as np

n_train0 = np.hstack([
    np.logspace(1, n, base=b, num=n, dtype=int)
    for b, n in [(1, 1), (2, 9), (7, 3), (700, 1)]
])
n_train0.sort()

n_test0 = n_valid0 = [100]

n_train = np.arange(1000, 7001, 1000)

# Fixed
n_test = n_valid = [1000]

# Dynamic
# n_test = n_valid = np.maximum(n_train // 7, 18)

try:
    arch_name = sys.argv[1]
except IndexError:
    arch_name = "flor"

for tr, te, v in chain(
    zip_longest(n_train0, n_test0, n_valid0, fillvalue=n_test0[0]),
    zip_longest(n_train, n_test, n_valid, fillvalue=n_test[0]),
):
    batch_size = min(tr, 16)
    model_path = Path(f"/scratch/interim/model2_{arch_name}_{tr}")
    arch = f"--arch {arch_name}"

    if (model_path / "output" / "washington" / arch_name / "evaluate.txt").exists():
        print(f"Model {model_path} already trained and tested. Skipping...")
        continue

    print(f"Preparing and tranforming model {model_path} with params {tr} {v} {te} ...")
    subprocess.check_call(
        "dawsonia prepare --label-path /scratch/interim/label_old --model-path"
        f" {model_path} {tr} {v} {te}".split()
    )
    subprocess.check_call(
        f"dawsonia ml {arch} --transform --model-path {model_path}".split()
    )
    print("Training ...")
    subprocess.check_call(
        f"dawsonia ml {arch} --train --batch-size {batch_size} --model-path"
        f" {model_path}".split()
    )
    print("Testing ...")
    subprocess.check_call(
        f"dawsonia ml {arch} --test --model-path {model_path}".split()
    )
