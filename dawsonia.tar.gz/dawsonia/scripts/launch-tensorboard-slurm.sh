#!/bin/bash
#SBATCH --job-name=tensorboard
#SBATCH --account=project_465000677
#SBATCH --partition=small    # Partition (queue) name
#SBATCH --exclusive
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --time=1:00:00

module load LUMI/22.08 partition/G
module load lumi-container-wrapper
module load rocm/5.3.3

PROJECT_PATH=/users/mohanana/
SCRATCH_PATH=/users/mohanana/project/dawsonia/

export PATH=$SCRATCH_PATH/bin:$PATH
srun --export=ALL $SCRATCH_PATH/bin/tensorboard serve --logdir $PROJECT_PATH/ai-for-obs/data/interim/model_tmp/output/washington/flor --port 6006 --bind_all
