import os
import subprocess
from pathlib import Path

from dawsonia.io import all_books, get_year

cwd = Path(__file__).parent.parent
os.chdir(cwd)
log_path = cwd / "log"
log_path.mkdir(exist_ok=True)

pdfs = list(all_books(cwd / "data" / "raw", ".pdf"))

print("Digitizing", len(pdfs), "PDFs ...")
for pdf in pdfs:
    try:
        year = get_year(pdf)
    except IOError:
        continue

    start_date = f"{year}-01-01"
    end_date = f"{year}-12-31"

    cmd = [
        "dawsonia",
        "digitize",
        "-c",
        # "cfg/dawsonia.toml",
        "cfg/lumi.toml",
        str(pdf),
        start_date,
        end_date,
    ]
    print("Executing", *cmd)
    process = subprocess.run(cmd, capture_output=True, text=True)
    if process.returncode != 0:
        print("FAILED!")
        (log_path / f"{pdf.name}_stderr.log").write_text(process.stderr)
        (log_path / f"{pdf.name}_stdout.log").write_text(process.stdout)
    else:
        print("SUCCESS!")
