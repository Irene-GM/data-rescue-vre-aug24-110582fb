#!/bin/bash
dawsonia label -c cfg/dawsonia.toml
