#!/bin/bash
#SBATCH --job-name=jupyter
#SBATCH --account=project_465000677
#SBATCH --exclusive
#SBATCH --mem=480g
#SBATCH --time=3:00:00
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --gpus-per-task=8
#SBATCH --hint=nomultithread

module load LUMI/22.08 partition/G
module load lumi-container-wrapper
module load rocm/5.3.3
# module load poppler/22.01.0-cpeGNU-22.08

BUILD=$PROJECT/dawsonia/build

export PATH=$BUILD/bin:$PATH
srun --cpu-bind=cores --export=ALL $PROJECT/utility-tools/start-jupyter --lab
