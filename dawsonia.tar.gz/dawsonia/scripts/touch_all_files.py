#!/usr/bin/env python
import concurrent.futures
import os
from datetime import datetime
from pathlib import Path

count = 0
now = datetime.now()


def touch_if_old(now, executor, root, files):
    for file in (root / fname for fname in files):
        if (now - datetime.fromtimestamp(file.stat().st_mtime)).days > 7:
            yield executor.submit(file.touch)


with concurrent.futures.ThreadPoolExecutor(max_workers=16) as executor:
    for path in [Path("/scratch"), Path("/flash")]:
        project = path / "project_465000677"  #  / "data" / "raw" / "KALMAR"
        if not project.exists():
            raise OSError(f"No such {project=}")

        for root, dirs, files in os.walk(project):
            root_path = Path(root)
            count += 1
            if count % 3 == 0:
                print("Nb. of directories = ", count)

            futures = [f for f in touch_if_old(now, executor, root_path, files)]
            concurrent.futures.wait(futures)


print("Total Nb. of directories = ", count)
