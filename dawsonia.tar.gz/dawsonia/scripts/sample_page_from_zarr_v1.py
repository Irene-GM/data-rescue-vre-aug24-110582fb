import json
import logging
import random
from concurrent.futures import ProcessPoolExecutor as Pool
from logging.handlers import RotatingFileHandler
from os import walk
from pathlib import Path

from dawsonia.io._zarr import (
    bytes_to_pil_image,
    iter_zarr_pages_ext,
    read_zarr_book,
)

here = Path(__file__).parent
raw_path = Path("/local_disk/data/ai-for-obs/raw_zarr/")
samples_path = raw_path.parent / "raw_samples"


logger = logging.getLogger("dawsonia")
logger.setLevel(logging.WARNING)
hdlr = RotatingFileHandler("sample_page.log")
logger.addHandler(hdlr)


def save_sample_from_zarr_book(here, raw_path, samples_path, zarr_book: Path):
    sample_stem = samples_path / zarr_book.relative_to(raw_path)
    metadata = sample_stem.with_suffix(".json")

    sample_stem.parent.mkdir(exist_ok=True, parents=True)

    try:
        first, last, book = read_zarr_book(
            zarr_book, 1, 10000, table_fmt_dir=here.parent / "table_formats"
        )
    except Exception as err:
        logger.warning(f"{err=} {zarr_book=}")
        raise
        # sample = None
        # first, last = check_zarr_book_page_range(zarr_book)
    else:
        # if not metadata.exists():
        metadata.write_text(json.dumps({"first": first, "last": last}))

        # if not sample.exists():
        page_nb = random.randint(first, last)
        byteimage, ext = next(iter_zarr_pages_ext(book.file, page_nb, page_nb + 1))
        if ext == "jpx":
            ext = "jp2"

        sample = sample_stem.with_suffix(f".{ext}")
        if sample.exists() and metadata.exists():
            if sample.stat().st_mtime > zarr_book.stat().st_mtime:
                msg = (
                    f"Exists: {sample.name} and {metadata.name} and is newer than book"
                )
                logger.warning(msg)
                return msg

        if ext in {"jpg", "jpeg"}:
            with sample.open("wb") as buf:
                buf.write(byteimage)
        else:
            # jpx case
            bytes_to_pil_image(byteimage).save(sample)

        return sample.name


fs = []
with Pool() as pool:
    for zarr_book in (
        Path(root) / file
        for root, _, files in walk(raw_path)
        for file in files
        if file.endswith("zarr.zip") and "img" not in file
    ):
        # save_sample_from_zarr_book(here, raw_path, samples_path, zarr_book)
        fs.append(
            pool.submit(
                save_sample_from_zarr_book, here, raw_path, samples_path, zarr_book
            )
        )


# with tqdm(total=len(fs)) as t:
#     for f in as_completed(fs):
#         t.set_postfix(file=f.result())

# plt.imshow(image)
