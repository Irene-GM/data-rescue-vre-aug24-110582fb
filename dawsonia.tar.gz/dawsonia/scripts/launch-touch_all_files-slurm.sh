#!/bin/bash
#SBATCH --job-name=touch_all_files   # Job name
#SBATCH --output=touch_all_files.stdout.%j # Name of stdout output file
#SBATCH --error=touch_all_files.stderr.%j  # Name of stderr error file
#SBATCH --account=project_465000677
#SBATCH --partition=small    # Partition (queue) name
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=16     # Number of cores (threads)
#SBATCH --time=1:00:00

set -e
module load LUMI/22.08 partition/C
module load cray-python

PROJECT_PATH=/users/mohanana/
SCRATCH_PATH=/users/mohanana/project/dawsonia/
WORKING_PATH=/users/mohanana/project/slurm

srun --export=ALL --cpu-bind=threads python $SCRATCH_PATH/scripts/touch_all_files.py
