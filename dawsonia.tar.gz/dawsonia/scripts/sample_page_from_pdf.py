import json
import logging
import random
from concurrent.futures import ProcessPoolExecutor as Pool
from concurrent.futures import as_completed
from os import walk
from pathlib import Path

import matplotlib.pyplot as plt
from dawsonia.io import (
    check_pdf_page_range,
    get_pages,
    read_pdf_book,
)
from tqdm import tqdm

here = Path(__file__).parent
raw_path = Path("/local_disk/data/ai-for-obs/raw/")
samples_path = raw_path.parent / "raw_samples"


logger = logging.getLogger("dawsonia")
logger.setLevel(logging.WARNING)


def save_sample_from_pdf(here, raw_path, samples_path, pdf):
    sample = samples_path / pdf.relative_to(raw_path).with_suffix(".png")
    metadata = sample.with_suffix(".json")

    if sample.exists() and metadata.exists():
        return f"Exists: {sample.name} and {metadata.name}"

    sample.parent.mkdir(exist_ok=True, parents=True)

    try:
        first, last, _ = read_pdf_book(
            pdf, 1, 10000, table_fmt_dir=here.parent / "table_formats"
        )
    except Exception as err:
        logger.warning(f"{err=} {pdf=}")
        # sample = None
        first, last = check_pdf_page_range(pdf)
    finally:
        if not metadata.exists():
            metadata.write_text(json.dumps({"first": first, "last": last}))

        if not sample.exists():
            page_nb = random.randint(first, last)
            image = get_pages(pdf, page_nb, page_nb + 1)
            plt.imsave(sample, image.astype("uint8"))

    return sample.name


fs = []
with Pool() as pool:
    for pdf in (
        Path(root) / file
        for root, _, files in walk(raw_path)
        for file in files
        if file.endswith("pdf") and "img" not in file
    ):
        fs.append(pool.submit(save_sample_from_pdf, here, raw_path, samples_path, pdf))


with tqdm(total=len(fs)) as t:
    for f in as_completed(fs):
        t.set_postfix(file=f.result())

# plt.imshow(image)
