#!/bin/bash
set -xe
dawsonia prepare -c cfg/dawsonia.toml
dawsonia ml --transform -c cfg/dawsonia.toml
dawsonia ml --train -c cfg/dawsonia.toml
