#!/usr/bin/env python3
import json
from datetime import datetime
from pathlib import Path

import gradio as gr
import pandas as pd
from dawsonia.config import read_configfile
from dawsonia.io import read_book

# config = read_configfile(Path("cfg/c21921.toml"))
config = read_configfile(Path("cfg/dawsonia.toml"))
cfg_digitize = config["dawsonia"]["digitize"]

model_path = Path(cfg_digitize["model_path"]).expanduser()
output_path = Path(cfg_digitize["output_path"]).expanduser()
raw_path = model_path.parent.parent / "raw_zarr"


def show_digitized(station_name: str, year: int, first_page: int, date_page: str):
    page_number = (
        int(first_page) + (pd.to_datetime(date_page) - datetime(int(year), 1, 1)).days
    )
    pdf = next((raw_path / station_name).glob(f"*{year}.zarr.zip"))
    first, last, book = read_book(pdf)
    image = book.read_page(page_number)
    # image = next(get_pages(pdf, page_number, page_number + 1))

    stem = pdf.name.split(".")[
        0
    ]  # to get the stem when 2 extensions are used like .zarr.zip
    output_path_page = output_path / station_name.lower() / stem / str(date_page)

    df = pd.read_parquet(output_path_page.with_suffix(".parquet"))
    df_prob = pd.read_parquet(
        (output_path_page.parent / "probablities" / output_path_page.name).with_suffix(
            ".parquet"
        )
    )
    stats = json.loads(
        (output_path_page.parent / "statistics" / output_path_page.name)
        .with_suffix(".json")
        .read_text()
    )
    meta = json.loads(
        (output_path_page.parent / "table_meta" / output_path_page.name)
        .with_suffix(".json")
        .read_text()
    )

    return image, df, df_prob, stats, meta


all_stations = [path_dir.name for path_dir in raw_path.iterdir()]


app = gr.Interface(
    show_digitized,
    inputs=[
        gr.Textbox(label="station name"),
        gr.Textbox(label="year"),
        gr.Textbox(label="page corresponding to 1st January"),
        gr.Textbox(label="date"),
    ],
    outputs=[
        gr.Image(label="raw"),
        gr.Dataframe(label="digitized"),
        gr.Dataframe(label="probablities"),
        gr.JSON(label="statistics"),
        gr.JSON(label="metadata"),
    ],
    examples=[
        [all_stations[0], 1927, 3, "1927-01-02"],
        ["KALMAR", 1932, 3, "1932-01-11"],
    ],
)
app.launch(server_name="0.0.0.0", share=True)
