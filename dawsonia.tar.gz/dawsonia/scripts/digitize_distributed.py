import os
from pathlib import Path

import horovod.tensorflow as hvd
import tensorflow as tf
from dawsonia.config import read_configfile
from dawsonia.digitize import digitize_book
from dawsonia.io import all_books, get_year


def digitize(path: Path) -> None:
    year = get_year(path)
    start_date = f"{year}-01-01"
    end_date = f"{year}-12-31"

    # an edge case, for example the books from KALMAR
    if "1938-0" in path.name:
        end_date = f"{year}-06-30"
    elif "1938-1" in path.name:
        start_date = f"{year}-07-01"

    config = read_configfile("cfg/singularity.toml")["dawsonia"]["digitize"]
    model_path = Path(config["model_path"])
    output_path = Path(config["output_path"])

    digitize_book(
        path,
        start_date,
        end_date,
        model_path=model_path,
        output_path=output_path,
        jobs=1,
    )


device = "GPU"

# Horovod: define a "static" local process set (for implementing send / scatter API)
# local_process_set = hvd.ProcessSet([hvd.local_rank()])

# Horovod: initialize Horovod.
hvd.init()

# Horovod: pin GPU to be used to process local rank (one GPU per process)
if device == "GPU":
    gpus = tf.config.experimental.list_physical_devices("GPU")
    for gpu in gpus:
        tf.config.experimental.set_memory_growth(gpu, True)
    if gpus:
        tf.config.experimental.set_visible_devices(gpus[hvd.local_rank()], "GPU")
else:
    os.environ["CUDA_VISIBLE_DEVICES"] = "-1"


with tf.device(device):
    rank = hvd.rank()
    index_skip = hvd.size()

    # Hovorod: Distributed the books over ranks (not local_rank)
    path_raw = "/scratch/raw_zarr"
    books = sorted(all_books(path_raw), key=lambda path: path.name)[rank::index_skip]

    print(f"Processing {len(books) = }:", books[0].name, "...", books[-1].name)

    for book in books:
        print(f"[{rank}] digitizing", book.name)
        digitize(book)
