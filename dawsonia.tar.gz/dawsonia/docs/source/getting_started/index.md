# Getting started

The following Jupyter notebooks should walk you through all the
key capabilities of Dawsonia.

```{toctree}
check_install.myst.ipynb
table_detect_scipy_proj.myst.ipynb
table_detect_opencv_contours.myst.ipynb
digitize.myst.ipynb
```

Once you have acquainted with Dawsonia, take a look at the
[user guide](../user_guide/index.md) and the
[API documentation](../apidocs/index.rst)
for a deep dive.
