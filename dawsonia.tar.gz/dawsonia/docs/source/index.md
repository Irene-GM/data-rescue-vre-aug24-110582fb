# Dawsonia

*Digitize hAndWritten obServatiONs In weather journAls*

Dawsonia is a young project aimed at data-rescue of weather journals stored as PDF / Zarr files.
Some of its salient features are:

::::{grid} 2
:::{grid-item-card}  {fas}`table;pst-color-primary` Table detection
Specializes in tables with grid lines, detecting both its position and structure
:::
:::{grid-item-card} {fas}`pencil;pst-color-primary` Handwritten text recognition
Built-in support for image-to-text AI to read handwritten numbers and symbols.
:::
::::

::::{grid} 2
:::{grid-item-card}  {fas}`gears;pst-color-primary` Customizable
TOML based configuration file to adapt to different table layouts
:::
:::{grid-item-card} {fas}`hand-holding-heart;pst-color-primary` Open-source
Free to use, modify and distribute. [Contributions welcome](contributing). AGPL-3.0 licensed.
:::
::::


The digitization pipeline is implemented in Python, using
well-known open-source scientific libraries.
NumPy, SciPy, Pandas, OpenCV, scikit-image, Tensorflow, scikit-learn, Typer... to name a few.

::::{grid} 1 1 2 3
```{button-link} ./install.html
:color: info
:shadow:
:expand:
Installation
```
```{button-link} ./getting_started/index.html
:color: success
:shadow:
:expand:
Getting started
```
```{button-link} ./hackathon_2024.html
:color: muted
:shadow:
:expand:
Hackathon 2024
```
::::

```{toctree}
:hidden:

install
Getting started <getting_started/index>
Hackathon 2024 <hackathon_2024>
```

```{toctree}
---
maxdepth: 1
caption: Contents
---
user_guide/index
API <apidocs/index>
wishlist
Chat with us <https://matrix.to/#/#aiforobs:matrix.org>
```


## Indices and tables

* {ref}`genindex`
* {ref}`modindex`
* {ref}`search`
