# Installation

The package can be installed directly from git.smhi.se. Start by

```sh
git clone https://git.smhi.se/ai-for-obs/dawsonia.git
```

```{dropdown} Do you plan to contribute back your changes?
Follow the [`git clone` command in contributing guide](contributing) instead.
```

Create a [virtual environment](https://packaging.python.org/en/latest/tutorials/installing-packages/#creating-and-using-virtual-environments),
activate it and change directory to repository that we just cloned now.

::::{tab-set}
:::{tab-item} Linux / macOS
:sync: tab1
```sh
python3 -m venv venv
source venv/bin/activate
cd dawsonia
python -m pip install invoke nox pip-tools
```
:::
:::{tab-item} Windows
:sync: tab2
```batch
py -m venv venv
venv\Scripts\activate
cd dawsonia
python -m pip install invoke nox pip-tools
```
:::
:::{tab-item} Conda / Mamba
:sync: tab3
```{note}
Install Miniforge as instructed here https://github.com/conda-forge/miniforge
```
:::
::::

```{important}
The package has been tested in Linux machines with Python 3.9 but other OS and newer Python versions can also work. **For non-Linux machines, Conda / Mamba is preferred.**
```

 To install the package, follow the most suitable approach based on the hardware your machine has.

::::{tab-set}
:::{tab-item} CPU
```sh
python -m pip install -r requirements/main.txt -e '.[cpu,pypi]'
```
:::
:::{tab-item} CPU (with AVX512)
```sh
python -m pip install -r requirements/main.txt -e '.[server,pypi]'
```
:::
:::{tab-item} GPU (AMD ROCm)
```sh
python -m pip install -r requirements/main.txt -e '.[rocm,pypi]'
```
:::
:::{tab-item} GPU (CUDA)
```sh
python -m pip install -r requirements/main.txt -e '.[cuda,pypi]'
```
:::
:::{tab-item} Conda / Mamba
:sync: tab3
```sh
# Either without pinned dependencies
mamba env create -f requirements/environment.yaml
# or with pinned dependencies
mamba env create -f requirements/environment_full.yaml
# followed by:
mamba activate dawsonia
python -m pip install -e '.[conda]'
```
:::
:::{tab-item} For dev
```{warning}
Intended to be used by developers only! To get exact versions `invoke dev.install`
```
:::
::::

```{button-link} ./getting_started.myst.html
:color: success
:shadow:
Proceed to Getting started ⏩
```
