# Configuration file for the Sphinx documentation builder.
#
# For the full list of built-in configuration values, see the documentation:
# https://www.sphinx-doc.org/en/master/usage/configuration.html

# -- Project information -----------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#project-information

import os
import warnings
from datetime import date
from importlib import metadata
from pathlib import Path

import dawsonia

# -- Project information -----------------------------------------------------

project = "Dawsonia"
_meta = metadata.metadata(project)
_today = date.today()
copyright = f"2022 - {_today.year}, SMHI. Published: {_today.isoformat()}"
author = "AiForObs project, SMHI"

version = ".".join(dawsonia.__version__.split(".")[:3])
# The full version, including alpha/beta/rc tags
release = dawsonia.__version__

_py_min_version = _meta.get("Requires-Python").split(">=")[-1]

rst_prolog = f"""
.. |author| replace:: {author}
.. |today| replace:: {_today}
.. |py_min_version| replace:: {_py_min_version}
"""

# -- General configuration ---------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#general-configuration

extensions = [
    # "sphinx.ext.autosummary",
    # "sphinx.ext.autodoc",
    "autodoc2",
    "sphinx.ext.intersphinx",
    "sphinx.ext.napoleon",
    "sphinx.ext.todo",
    "sphinx.ext.viewcode",
    "myst_nb",
    "sphinx_click",
    "sphinx_search.extension",  # provided by readthedocs-sphinx-search
    "sphinx_copybutton",
    "sphinxcontrib.mermaid",
    "sphinx_design",
    "hoverxref.extension",
    # "sphinx_tippy",
]

templates_path = ["_templates"]
exclude_patterns: list[str] = []

# The suffix of source filenames.
source_suffix = {
    ".rst": "restructuredtext",
    ".ipynb": "myst-nb",
    ".myst.md": "myst-nb",
}

# sphinx-autodoc2
autodoc2_render_plugin = "myst"
autodoc2_packages = ["../../src/dawsonia"]

intersphinx_mapping = {
    "numpy": ("https://numpy.org/doc/stable/", None),
    "python": ("https://docs.python.org/3/", None),
    "scipy": ("https://docs.scipy.org/doc/scipy-1.13.1/", None),
    "pandas": ("https://pandas.pydata.org/pandas-docs/stable/", None),
    "sklearn": ("https://scikit-learn.org/stable/", None),
}

# sphinx-hoverxref
hoverxref_auto_ref = True  # to enable for all :ref:
hoverxref_domains = ["py"]  # to enable for all :py:func:, :py:mod:, :py:class:
hoverxref_role_types = {
    "attr": "tooltip",
    "class": "tooltip",  # for Python Sphinx Domain
    "confval": "tooltip",  # for custom object
    "const": "tooltip",
    "exc": "tooltip",
    "func": "tooltip",  # for Python Sphinx Domain
    "hoverxref": "modal",
    "meth": "tooltip",
    "mod": "tooltip",  # for Python Sphinx Domain
    "obj": "tooltip",  # for Python Sphinx Domain
    "ref": "tooltip",  # for hoverxref_auto_ref config
}
# hoverxref_intersphinx = [
#     "numpy",
#     "python",
# ]
# hoverxref_intersphinx_types = {
#     "numpy": "modal",
#     "python": "tooltip",
# }

# -- MyST and myst-nb options ------------------------------------------------

# Execute ipynb files into with a cache ...
nb_execution_mode = "cache"
# ... except these ipynb files
nb_execution_excludepatterns = ["**/*.ipynb", "debug/**/*"]
nb_execution_raise_on_error = True
nb_execution_show_tb = True
nb_execution_timeout = 600
nb_merge_streams = True

myst_enable_extensions = [
    "amsmath",
    "colon_fence",
    "deflist",
    "dollarmath",
    "fieldlist",
    "html_admonition",
    "html_image",
    "linkify",
    "replacements",
    "smartquotes",
    "strikethrough",
    "substitution",
    "tasklist",
]
myst_heading_anchors = 3

# -- Other options ------------------------------------------------------------
autosummary_generate = True

autodoc_default_options = {
    "members": True,
    "member-order": "bysource",
    #  'special-members': '__init__',
    "undoc-members": True,
    "exclude-members": "__weakref__",
    "inherited-members": True,
}
autodoc_mock_imports = ["IPython"]

todo_include_todos = True

napoleon_numpy_docstring = True


# -- Options for HTML output -------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#options-for-html-output

# FIXME:
# https://github.com/executablebooks/sphinx-book-theme/issues/729
#  Extension error (pydata_sphinx_theme):
# Handler <function update_and_remove_templates at 0x7f49ee7c4790> for event
# 'html-page-context' threw an exception (exception:
# toggle-primary-sidebar.html)
# html_theme = "sphinx_book_theme"
html_theme = "pydata_sphinx_theme"
html_static_path = ["_static"]
html_css_files = ["css/tippy.css"]
if os.getenv("READTHEDOCS"):
    html_css_files.append("css/rtd_search_overrides.css")

_git_repo = "https://git.smhi.se/ai-for-obs/dawsonia"


def _custom_edit_url(
    gitlab_user,
    gitlab_repo,
    gitlab_branch,
    doc_path,
    file_name,
    default_edit_page_url_template,
):
    """Create custom 'edit' URLs for API modules since they are dynamically generated.
    Courtesy: https://github.com/vispy/vispy/pull/2220/files
    """
    if file_name.startswith("apidocs/"):
        # this is a dynamically generated API page, link to actual Python source
        modpath = Path(Path(*os.path.split(file_name)[1:]).stem.replace(".", os.sep))

        if modpath == "modules":
            # main package listing
            modpath = "src/dawsonia"

        rel_modpath = Path("..", "src", modpath)
        if rel_modpath.is_dir():
            doc_path = modpath
            file_name = "__init__.py"
        elif rel_modpath.with_suffix(".py").is_file():
            doc_path = modpath
            file_name = modpath.with_suffix(".py").name
        else:
            warnings.warn(
                f"Not sure how to generate the API URL for: {file_name},"
                f" {rel_modpath =}"
            )
    return default_edit_page_url_template.format(
        gitlab_user=gitlab_user,
        gitlab_repo=gitlab_repo,
        gitlab_branch=gitlab_branch,
        doc_path=doc_path,
        file_name=file_name,
    )


# html_logo = html_favicon = "_static/smhi_logo/black.svg"

html_context = {
    "gitlab_user": Path(_git_repo).parent.name,
    "gitlab_repo": Path(_git_repo).name,
    "gitlab_version": "42",
    "gitlab_branch": "main",
    "doc_path": "docs/source",
    "edit_page_url_template": (
        "{{ dawsonia_custom_edit_url(gitlab_user, gitlab_repo, gitlab_branch, doc_path,"
        " file_name, default_edit_page_url_template) }}"
    ),
    "default_edit_page_url_template": "https://git.smhi.se/-/ide/project/{gitlab_user}/{gitlab_repo}/edit/{gitlab_branch}/-/{doc_path}/{file_name}",  # noqa
    "dawsonia_custom_edit_url": _custom_edit_url,
}
html_theme_options = {
    "use_edit_page_button": True,
    # -- for sphinx_book_theme
    # "home_page_in_toc": True,
    # "repository_url": _git_repo,
    # "repository_provider": "gitlab",
    # "repository_branch": "main",
    # "path_to_docs": "docs",
    # "use_repository_button": True,
    # "use_issues_button": True,
    # -- for pydata_sphinx_theme
    "icon_links": [
        {
            "name": "SMHI Gitlab",
            "url": _git_repo,
            "icon": "fa-brands fa-gitlab",
        },
        # {
        #     "name": "PyPI",
        #     "url": "https://pypi.org/project/dawsonia",
        #     "icon": "fa-custom fa-pypi",
        # },
    ],
    "logo": {
        "text": "Dawsonia",
        "image_dark": "_static/smhi_logo_white.svg",
        "image_light": "_static/smhi_logo_black.svg",
        "alt_text": "An SMHI project",
    },
}
# CSS selector which modifies the sphinx-copybutton feature
copybutton_selector = ",".join([
    f"div.highlight-{css_class} div.highlight pre"
    for css_class in ("python", "ipython3", "sh", "ini", "default")
])

# Primary sidebar disabled for some pages
html_sidebars = {
    "install": [],
    "getting_started/*.myst": [],
    "wishlist": [],
    "hackathon_2024": [],
}

if os.getenv("READTHEDOCS"):

    def setup(app):
        app.add_js_file("js/rtd_search_close.js")
